﻿namespace Tarea_PabloAndreValencianoBlanco.Models
{
	public class Software
	{
		public int Id_Software { get; set; }
		public required string Descripcion { get; set; }
		public required string Version { get; set; }
	}
}

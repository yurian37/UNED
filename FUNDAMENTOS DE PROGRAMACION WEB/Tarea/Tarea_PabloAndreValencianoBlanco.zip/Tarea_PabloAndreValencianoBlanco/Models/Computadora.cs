﻿namespace Tarea_PabloAndreValencianoBlanco.Models
{
	public class Computadora
	{
		public int Id_Computadora { get; set; }
		public required string Marca { get; set; }
		public required string Tipo { get; set; }
		public int AnioFabricacion { get; set; }
		public List<Software> SoftwareInstalado { get; set; } = new();
	}
}

﻿using Microsoft.AspNetCore.Mvc;
using Tarea_PabloAndreValencianoBlanco.Models;


namespace Tarea_PabloAndreValencianoBlanco.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class ComputadorasController : ControllerBase
	{
		private static List<Computadora> computadoras = new();

		// GET: Listar el software de una computadora
		[HttpGet("{id}/software")]
		public ActionResult<List<Software>> GetSoftware(int id)
		{
			var comp = computadoras.FirstOrDefault(c => c.Id_Computadora == id);
			if (comp == null) return NotFound("Computadora no encontrada");
			return Ok(comp.SoftwareInstalado);
		}

		// POST: Agregar una computadora
		[HttpPost]
		public ActionResult AddComputadora([FromBody] Computadora comp)
		{
			computadoras.Add(comp);
			return Ok();
		}

		// POST: Agregar software a una computadora
		[HttpPost("{id}/software")]
		public ActionResult AddSoftware(int id, [FromBody] Software soft)
		{
			var comp = computadoras.FirstOrDefault(c => c.Id_Computadora == id);
			if (comp == null) return NotFound("Computadora no encontrada");
			comp.SoftwareInstalado.Add(soft);
			return Ok();
		}

		// PUT: Actualizar software
		[HttpPut("{id}/software/{idSoft}")]
		public ActionResult UpdateSoftware(int id, int idSoft, [FromBody] Software nuevo)
		{
			var comp = computadoras.FirstOrDefault(c => c.Id_Computadora == id);
			if (comp == null) return NotFound("Computadora no encontrada");

			var soft = comp.SoftwareInstalado.FirstOrDefault(s => s.Id_Software == idSoft);
			if (soft == null) return NotFound("Software no encontrado");

			soft.Descripcion = nuevo.Descripcion;
			soft.Version = nuevo.Version;
			return Ok();
		}

		// DELETE: Eliminar software
		[HttpDelete("{id}/software/{idSoft}")]
		public ActionResult DeleteSoftware(int id, int idSoft)
		{
			var comp = computadoras.FirstOrDefault(c => c.Id_Computadora == id);
			if (comp == null) return NotFound("Computadora no encontrada");

			var soft = comp.SoftwareInstalado.FirstOrDefault(s => s.Id_Software == idSoft);
			if (soft == null) return NotFound("Software no encontrado");

			comp.SoftwareInstalado.Remove(soft);
			return Ok();
		}

		// GET: Mostrar todas las computadoras
		[HttpGet]
		public ActionResult<List<Computadora>> GetComputadoras()
		{
			return Ok(computadoras);
		}
	}
}

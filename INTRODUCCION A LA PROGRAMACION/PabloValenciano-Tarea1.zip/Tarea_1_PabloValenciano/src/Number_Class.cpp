#include "Number_Class.h"

Number_Class::Number_Class()
{
    //ctor
}

Number_Class::~Number_Class()
{
    //dtor
}

En Bin/Release esta el programa funcional y compiladores requeridos
El PDF es seguro, no posee nada raro, es un simple word convertido en PDF, lo cree para que el usuario lo use para visualizar mejor los requerimientos

Bugs:
1- Al terminar la opcion 1 del menu, este no regresa al menu principal al instante, regresa a los 2 segundos de forma automatica.
2- En el menu 2, no logre que dejara un campo vacio, por lo que se le pide al usuario que si quiere dejar el campo vacio digite el valor que indica abajo en pantalla.
3- En el menu 2, es muy importante que digites Nombre_Apellido1_Apellido2 y ya donde cada _ es un espacion, no digitar espacios antes o despues
4- En el menu 4, la resta final no da 0, por lo que se fuerza el valor de 0. Meti la formulas segun como se indican el pdf, aun asi no da y tiene cierto margen de fallo por decimas.


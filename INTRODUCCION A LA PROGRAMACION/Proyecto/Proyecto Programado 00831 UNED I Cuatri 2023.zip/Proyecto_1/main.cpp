#include <iostream>
#include <string>
#include <vector>
#include "Funciones.h"

using namespace std;

bool Access_Allowed=false;
const unsigned int max_attempts_login=3;
const string Usuarios="Usuarios.txt";
vector <string> Users;
vector <string> Pwds;
const string Titulo_principal="Menu Principal";
const vector <string> Opciones_Menu_Principal={"Departamentos","Activos","Salir"};
const string Titulo_Depa="Departamentos";
const vector <string> Opciones_Depa={"Registros", "Consultar"};
const string Titulo_Acti="Activos";
const vector <string> Opciones_Acti={"Registros","Consultar","Reporte General"};
const string Titulo_Cons="Consultar Activos";
const vector <string> Opciones_Cons={"Por Persona", "Por departamento"};

int Yes_No(){
    bool valid=false;
    char Option[10];
    while(!valid){
        gotoxy(0,18);
        cout << "Deseas continuar S/N: ";
        cin.getline(Option,10);
        if(strcmp(Option,"S")){
            valid=true;
            return 0;
        }
        else if(strcmp(Option,"N")){
            valid=true;
            return 1;
        }
        else{
            gotoxy(0,19);
            cout << "Dato no valido, vuelva a ingresar";
            gotoxy(21,18);
            cout << "          ";
            valid=false;
        }
    }
}

void Registrar_Depa(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Registar Departamento");
        continuar=Yes_No();
    }
}

void Consultar_Depa(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Consultar Departamento");
        continuar=Yes_No();
    }
}

void Registrar_Acti(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Registar Activo");
        continuar=Yes_No();
    }
}

void Consultar_Acti_por_Persona(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Consultar Activos por persona");
        continuar=Yes_No();
    }
}

void Consultar_Acti_por_Depa(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Consultar Activos por departamento");
        continuar=Yes_No();
    }
}

void Reporte_General_Acti(){
    int continuar=1;
    while(continuar==1){
        system("CLS");
        Titulo("Reporte General");
        continuar=Yes_No();
    }
}

int ConverttxtFile_to_Matriz_2(string filename){
    ifstream infile;
    infile.open(filename);
    unsigned int fila;
    string a,b;
    if (!infile.is_open()) {
        std::cout << "No se pudo abrir el archivo" << endl;
        return 1;
    }
    else{
        string line;
        vector<string> data;
        while (infile >> a >> b){
            fila++;
            Users.resize(fila);
            Pwds.resize(fila);
            Users[fila-1]=a;
            Pwds[fila-1]=b;
        }
    }
    infile.close();
    return 0;
}

int main()
{
    bool Salir=false;
    int Option_Choosen;
    ConverttxtFile_to_Matriz_2(Usuarios);
    Access_Allowed=Login_Access(max_attempts_login,Users,Pwds);
    if (Access_Allowed){
        while(!Salir){
            Option_Choosen=0;
            system("CLS");
            Option_Choosen=menu(Titulo_principal,Opciones_Menu_Principal);
            switch(Option_Choosen){
            case 1:
                //Departamentos
                Option_Choosen=0;
                system("CLS");
                Option_Choosen=menu(Titulo_Depa,Opciones_Depa);
                switch(Option_Choosen){
                case 1:
                    //Registrar
                    Registrar_Depa();
                    break;
                case 2:
                    //Consultar
                    Consultar_Depa();
                    break;
                }
                break;
            case 2:
                //Activos
                Option_Choosen=0;
                system("CLS");
                Option_Choosen=menu(Titulo_Acti,Opciones_Acti);
                switch(Option_Choosen){
                case 1:
                    //Registrar
                    Registrar_Acti();
                    break;
                case 2:
                    //Consultar
                    Option_Choosen=0;
                    system("CLS");
                    Option_Choosen=menu(Titulo_Cons,Opciones_Cons);
                    switch(Option_Choosen){
                    case 1:
                        //Por Personal
                        Consultar_Acti_por_Persona();
                        break;
                    case 2:
                        //Por departamento
                        Consultar_Acti_por_Depa();
                        break;
                    }
                    break;
                case 3:
                    //Reporte Genenar
                    Reporte_General_Acti();
                    break;
                }
                break;
            case 3:
                Salir=true;
                break;
            }
        }
    }
}

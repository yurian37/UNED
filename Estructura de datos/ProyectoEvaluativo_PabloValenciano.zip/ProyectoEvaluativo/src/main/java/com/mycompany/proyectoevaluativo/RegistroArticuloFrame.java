/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */


//Librerias a usar
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


//Clase de la interfaz para registrar articulo.
public class RegistroArticuloFrame extends JFrame {
    private ArticuloManager articuloManager;
    private JTextField textFieldId;
    private JTextField textFieldNombre;
    private JTextField textFieldPrecio;
    private JButton registerButton;
    private JTextArea displayArea;

    //Constructor e inicio de la interfaz
    public RegistroArticuloFrame(ArticuloManager articuloManager) {
        this.articuloManager = articuloManager;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Registro de Artículos");
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        add(panel);

        JLabel labelId = new JLabel("ID (autogenerado):");
        textFieldId = new JTextField();
        textFieldId.setEditable(false);
        generateUniqueId();

        JLabel labelNombre = new JLabel("Nombre:");
        textFieldNombre = new JTextField();

        JLabel labelPrecio = new JLabel("Precio:");
        textFieldPrecio = new JTextField();

        registerButton = new JButton("Registrar");
        registerButton.addActionListener(new RegisterButtonListener());

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        panel.add(labelId);
        panel.add(textFieldId);
        panel.add(labelNombre);
        panel.add(textFieldNombre);
        panel.add(labelPrecio);
        panel.add(textFieldPrecio);
        panel.add(new JLabel(""));
        panel.add(registerButton);

        add(panel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    //Funcion para generar el id aleatorio
    private void generateUniqueId() {
        Random random = new Random();
        int id;
        do {
            // Genera un número entre 100 y 999
            id = 100 + random.nextInt(900); 
        } while (!isUniqueId(id)); //Revision que ningun otro elemento de la lista tenga el ID
        textFieldId.setText(String.valueOf(id));
    }

    //Revision de que el id sea unico
    private boolean isUniqueId(int id) {
        if (articuloManager.getArticulos() == null || articuloManager.getArticulos().getHead() == null) {
            return true;
        }
        SimpleNode<Articulo> current = articuloManager.getArticulos().getHead();
        while (current != null) {
            if (current.getData().getIdArticulo() == id) {
                return false;
            }
            current = current.getNext();
        }
        return true;
    }

    //Funcion del boton registrar
    private class RegisterButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int id = Integer.parseInt(textFieldId.getText());
                String nombre = textFieldNombre.getText();
                double precio = Double.parseDouble(textFieldPrecio.getText());

                //Mensaje de error si el nombre esta vacio
                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Articulo articulo = new Articulo(id, nombre, precio);
                articuloManager.addArticulo(articulo);
                displayArea.append("Artículo registrado: " + articulo.getNombre() + "\n");
                generateUniqueId(); // Generar un nuevo ID único
                textFieldNombre.setText("");
                textFieldPrecio.setText("");
            } catch (NumberFormatException ex) {
                //Mensaje de error si lo ingresado en el precio no es decimal.
                JOptionPane.showMessageDialog(null, "El precio debe ser un número decimal válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}



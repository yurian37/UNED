/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

//Diseno del nodo
public class SimpleNode<T> {
    private T data;
    private SimpleNode<T> next;

    public SimpleNode(T data) {
        this.data = data;
        this.next = null;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public SimpleNode<T> getNext() {
        return next;
    }

    public void setNext(SimpleNode<T> next) {
        this.next = next;
    }
}

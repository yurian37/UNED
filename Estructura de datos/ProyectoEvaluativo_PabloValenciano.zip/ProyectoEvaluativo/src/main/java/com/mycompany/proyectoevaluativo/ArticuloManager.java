/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

//Clase que maneja la lista enlazada
public class ArticuloManager {
    private SimpleLinkedList<Articulo> articulos;

    public ArticuloManager() {
        this.articulos = new SimpleLinkedList<>();
    }

    //Obtener la lista enlazada
    public SimpleLinkedList<Articulo> getArticulos() {
        return articulos;
    }

    //Funcion para agregar listar enlazadas, con la explicacion para que quede ordenada con el id del articulo
    public void addArticulo(Articulo articulo) {
        SimpleNode<Articulo> newNode = new SimpleNode<>(articulo);
        if (articulos.getHead() == null || articulos.getHead().getData().getIdArticulo() >= articulo.getIdArticulo()) {
            newNode.setNext(articulos.getHead());
            articulos.setHead(newNode);
        } else {
            SimpleNode<Articulo> current = articulos.getHead();
            while (current.getNext() != null && current.getNext().getData().getIdArticulo() < articulo.getIdArticulo()) {
                current = current.getNext();
            }
            newNode.setNext(current.getNext());
            current.setNext(newNode);
        }
    }
}


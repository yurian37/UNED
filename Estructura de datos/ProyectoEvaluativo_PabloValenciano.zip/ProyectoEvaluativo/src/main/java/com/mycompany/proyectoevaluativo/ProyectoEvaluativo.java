/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

package com.mycompany.proyectoevaluativo;

//Librerias a usar para el menu principal
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author pvale
 */
public class ProyectoEvaluativo extends JFrame {
    
    private ArticuloManager articuloManager = new ArticuloManager();;
    //Inicio del constructor
    public ProyectoEvaluativo() {
        initializeUI();
    }

    //Interfaz del menu principal
    private void initializeUI() {
        setTitle("Titulo");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Crear botones
        JButton button1 = new JButton("Registrar Articulo de Ferreteria");
        JButton button2 = new JButton("Listar Articulos de Ferreteria");
        JButton button3 = new JButton("Mostrar Promedio de Precios");

        // Ponerle color a los botones
        button1.setBackground(Color.GREEN);
        button2.setBackground(Color.CYAN);
        button3.setBackground(Color.ORANGE);

        // Ponerle una unica fuente estilizada a cada boton
        Font buttonFont = new Font("Arial", Font.BOLD, 16);
        button1.setFont(buttonFont);
        button2.setFont(buttonFont);
        button3.setFont(buttonFont);

        // Colocar los botones en la interfaz
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(button1, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(button2, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(button3, gbc);


        setLocationRelativeTo(null);
        
        //Funcionalidad de Botones
        //Boton para registrar articulos
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegistroArticuloFrame(articuloManager).setVisible(true);
            }
        });
        
        //Boton para listar los articulos
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ListarArticulosFrame(articuloManager).setVisible(true);
            }
        });
        
        //Boton para calcular el promedio
        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MostrarPromedioFrame(articuloManager).setVisible(true);
            }
        });
        
    }
    
    //Llamada que inicia todo
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ProyectoEvaluativo().setVisible(true);
            }
        });
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

//Diseno de una Lista enlazada simple usando el nodo head
public class SimpleLinkedList<T> {
    private SimpleNode<T> head;

    public SimpleLinkedList() {
        this.head = null;
    }

    public SimpleNode<T> getHead() {
        return head;
    }

    public void setHead(SimpleNode<T> head) {
        this.head = head;
    }

    public void add(T data) {
        SimpleNode<T> newNode = new SimpleNode<>(data);
        if (head == null) {
            head = newNode;
        } else {
            SimpleNode<T> temp = head;
            while (temp.getNext() != null) {
                temp = temp.getNext();
            }
            temp.setNext(newNode);
        }
    }

    public void delete(T data) {
        if (head == null) {
            return;
        }

        if (head.getData().equals(data)) {
            head = head.getNext();
            return;
        }

        SimpleNode<T> temp = head;
        while (temp.getNext() != null && !temp.getNext().getData().equals(data)) {
            temp = temp.getNext();
        }

        if (temp.getNext() != null) {
            temp.setNext(temp.getNext().getNext());
        }
    }

    public void printList() {
        SimpleNode<T> temp = head;
        while (temp != null) {
            System.out.println(temp.getData());
            temp = temp.getNext();
        }
    }
}


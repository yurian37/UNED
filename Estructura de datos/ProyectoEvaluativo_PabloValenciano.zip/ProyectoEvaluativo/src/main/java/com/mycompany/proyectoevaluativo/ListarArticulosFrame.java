/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

//Librerias a usar
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

//Clase de la interfaz para listar los articulos
public class ListarArticulosFrame extends JFrame {
    private ArticuloManager articuloManager;
    private JTable table;
    private DefaultTableModel tableModel;

    //Constructor e Inicio de interfaz
    public ListarArticulosFrame(ArticuloManager articuloManager) {
        this.articuloManager = articuloManager;
        initializeUI();
    }

    //Inicio de Interfaz
    private void initializeUI() {
        setTitle("Listado de Artículos");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnNames = {"ID", "Nombre", "Precio"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        loadArticulos();

        add(scrollPane, BorderLayout.CENTER);
    }

    //Carga de la lista enlazada a la Tabla
    private void loadArticulos() {
        SimpleNode<Articulo> current = articuloManager.getArticulos().getHead();
        while (current != null) {
            Articulo articulo = current.getData();
            Object[] row = {articulo.getIdArticulo(), articulo.getNombre(), articulo.getPrecio()};
            tableModel.addRow(row);
            current = current.getNext();
        }
    }
}


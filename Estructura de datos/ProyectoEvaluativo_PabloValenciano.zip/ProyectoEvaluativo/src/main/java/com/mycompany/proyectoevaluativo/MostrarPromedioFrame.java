/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoevaluativo;

/* UNED II Cuatrimestre 2024
 * * ProyectoEvaluativo: Listas Enlazadas
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 28/07/2024
 * 
 * */

//Librerias a usar
import javax.swing.*;
import java.awt.*;

//Clase de la interfaz para el calculo del promedio
public class MostrarPromedioFrame extends JFrame {
    private ArticuloManager articuloManager;
    private JLabel promedioLabel;

    //Constructor y ejecutor de la interfaz
    public MostrarPromedioFrame(ArticuloManager articuloManager) {
        this.articuloManager = articuloManager;
        initializeUI();
    }

    //Interfaz
    private void initializeUI() {
        setTitle("Promedio de Precios");
        setSize(300, 200);
        setLocationRelativeTo(null);

        promedioLabel = new JLabel("Promedio: ");
        promedioLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        promedioLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(promedioLabel, BorderLayout.CENTER);

        //Llamada al calculo del promedio
        calculateAndDisplayAverage();
    }

    //Calculo del promedio
    private void calculateAndDisplayAverage() {
        double sum = 0;
        int count = 0;
        SimpleNode<Articulo> current = articuloManager.getArticulos().getHead();

        while (current != null) {
            sum += current.getData().getPrecio();
            count++;
            current = current.getNext();
        }

        double average = (count > 0) ? sum / count : 0;
        promedioLabel.setText("Promedio: " + average);
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
//Clase de Pedido

public class Pedido {
    private String id;
    private String tipoCamiseta;
    private String talla;
    private String cantidad;
    private String codigoDiseno;
    private String tipoPedido;
    private String direccion;
    private String formaPago;
    private String telefono;
    private String nombre;
    
    public Pedido(String id, String tipoCamiseta, String talla, String cantidad, String codigoDiseno, String tipoPedido,
            String direccion, String formaPago, String telefono, String nombre){
        this.id = id;
        this.tipoCamiseta = tipoCamiseta;
        this.talla = talla;
        this.cantidad = cantidad;
        this.codigoDiseno = codigoDiseno;
        this.tipoPedido = tipoPedido;
        this.direccion = direccion;
        this.formaPago = formaPago;
        this.telefono = telefono;
        this.nombre = nombre;
    }
    
    public String getId() {
        return id;
    }

    public String getTipoCamiseta() {
        return tipoCamiseta;
    }

    public void setTipoCamiseta(String tipoCamiseta) {
        this.tipoCamiseta = tipoCamiseta;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodigoDiseno() {
        return codigoDiseno;
    }

    public void setCodigoDiseno(String codigoDiseno) {
        this.codigoDiseno = codigoDiseno;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

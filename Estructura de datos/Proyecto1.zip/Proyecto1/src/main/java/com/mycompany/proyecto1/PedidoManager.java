/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;


//Clase creada para manejar los pedidos en casi todo el resto de clases, se encarga de llevar la lista de Pedidos
public class PedidoManager {
    private List<Pedido> pedidos;

    public PedidoManager() {
        this.pedidos = new ArrayList<>();
    }

    // Agregar un nuevo pedido
    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    // Eliminar un pedido por ID
    public boolean eliminarPedido(String id) {
        return pedidos.removeIf(p -> p.getId().equals(id));
    }

    // Buscar un pedido por ID
    public Optional<Pedido> buscarPedido(String id) {
        return pedidos.stream()
                      .filter(p -> p.getId().equals(id))
                      .findFirst();
    }

    // Obtener la lista de todos los pedidos
    public List<Pedido> listarPedidos() {
        return new ArrayList<>(pedidos); // Devolver una copia para evitar modificaciones externas
    }

    // Comparar valores de pedidos por cantidad)
    public List<Pedido> compararPedidosPorCantidad() {
        List<Pedido> sortedPedidos = new ArrayList<>(pedidos);
        sortedPedidos.sort(Comparator.comparingInt(p -> Integer.parseInt(p.getCantidad())));
        return sortedPedidos;
    }

    
    // Método para buscar pedidos por número de teléfono
    public List<Pedido> buscarPorTelefono(String telefono) {
        List<Pedido> resultados = new ArrayList<>();
        for (Pedido pedido : pedidos) {
            if (pedido.getTelefono().equals(telefono)) {
                resultados.add(pedido);
            }
        }
        return resultados;
    }
    
    // Método para buscar un pedido por su ID
    public Pedido buscarPorId(int id) {
        for (Pedido pedido : pedidos) {
            if (Integer.parseInt(pedido.getId()) == id) {
                return pedido;
            }
        }
        return null; // Retorna null si no se encuentra el pedido con el ID especificado
    }
    
    // Método para obtener todos los pedidos
    public List<Pedido> getPedidos() {
        return pedidos;
    }
    
    // Método para actualizar un pedido existente
    public void actualizarPedido(Pedido pedidoActualizado) {
        for (int i = 0; i < pedidos.size(); i++) {
            Pedido pedido = pedidos.get(i);
            if (pedido.getId().equals(pedidoActualizado.getId())) {
                pedidos.set(i, pedidoActualizado);
                break;
            }
        }
    }
}


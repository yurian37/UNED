/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
//Ventana de Busqueda por Telefono y Seleccion para edicion

//Librerias requeridas
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class BusquedaEdicionPedidosFrame extends JFrame {
    // Estructuras que se van a usar para la construccion
    private PedidoManager pedidoManager;
    private JTextField telefonoField;
    private JTable resultadosTable;
    private PedidoTableModel tableModel;

    //Constructor e Iniciador de la interfaz
    public BusquedaEdicionPedidosFrame(PedidoManager pedidoManager) {
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Interfaz
    private void initializeUI() {
        //Creacion del diseno de la interfaz
        setTitle("Búsqueda y Edición de Pedidos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        
        //Texto, caja de texto y boton
        JLabel telefonoLabel = new JLabel("Número de Teléfono:");
        telefonoField = new JTextField(10);
        ((AbstractDocument) telefonoField.getDocument()).setDocumentFilter(new BusquedaEdicionPedidosFrame.NumericDocumentFilter (8));
        JButton buscarButton = new JButton("Buscar");

        buscarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPedidos();
            }
        });
        
        // Posicion de los elementos recien creados
        topPanel.add(telefonoLabel);
        topPanel.add(telefonoField);
        topPanel.add(buscarButton);

        //Creacion de la tabla
        tableModel = new PedidoTableModel();
        resultadosTable = new JTable(tableModel);

        resultadosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        resultadosTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && resultadosTable.getSelectedRow() != -1) {
                editarPedido(resultadosTable.getSelectedRow());
            }
        });

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(resultadosTable), BorderLayout.CENTER);

        setLocationRelativeTo(null);
        
    }

    //Metodo que ingresa los datos a la table
    private void buscarPedidos() {
        String telefono = telefonoField.getText().trim();
        //Metodo del pedidoManager para buscar entre la lista de Pedidos, aquellos que poseen el mismo numero de telefono
        List<Pedido> resultados = pedidoManager.buscarPorTelefono(telefono);
        tableModel.setPedidos(resultados);
    }

    //Metodo para abrir la ventana de edicion, cuando se selecciona una fila
    private void editarPedido(int rowIndex) {
        Pedido pedido = tableModel.getPedidoAt(rowIndex);
        EdicionPedidoDialog dialog = new EdicionPedidoDialog(this, pedidoManager, pedido);
        dialog.setVisible(true);
        tableModel.fireTableDataChanged(); // Refresh table after editing
    }
    
    //Filtro para los JTextBox, este hace que solo pueda ingresar numeros y solo permitiendo un maximo de 8 caracteres
    public static class NumericDocumentFilter extends DocumentFilter {
        private int maxLength;

        public NumericDocumentFilter(int maxLength) {
            this.maxLength = maxLength;
        }

        @Override
        public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string == null) {
                return;
            }

            if ((fb.getDocument().getLength() + string.length()) <= maxLength && string.matches("\\d*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }

            if ((fb.getDocument().getLength() + text.length() - length) <= maxLength && text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
    
}

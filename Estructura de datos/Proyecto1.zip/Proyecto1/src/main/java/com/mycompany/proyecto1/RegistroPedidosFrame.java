/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
import javax.swing.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

//Funcion que genera la interfas y las funcionilades para registrar un pedido
public class RegistroPedidosFrame extends JFrame {
    private PedidoManager pedidoManager;
    private JTextField textFieldCantidad;
    private JTextField textFieldCodigoDiseno;
    private JTextField textFieldDireccion;
    private JTextField textFieldTelefono;
    private JTextField textFieldNombre;
    private JComboBox<String> comboBoxTipoCamiseta;
    private JComboBox<String> comboBoxTalla;
    private JComboBox<String> comboBoxTipoPedido;
    private JComboBox<String> comboBoxFormaPago;

    //Llamada al interfaz de registro
    public RegistroPedidosFrame(PedidoManager pedidoManager) {
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Inicio de Interfaz
    private void initializeUI() {
        setTitle("Registro de Pedidos");
        setSize(600, 600);
        setLayout(new GridLayout(12, 2, 10, 10));

        JLabel labelId = new JLabel("ID:");
        JTextField textFieldId = new JTextField();
        textFieldId.setEditable(false);
        // Autogenerar ID
        textFieldId.setText(String.valueOf(pedidoManager.listarPedidos().size() + 1));  

        JLabel labelTipoCamiseta = new JLabel("Tipo de Camiseta:");
        comboBoxTipoCamiseta = new JComboBox<>(new String[]{
                "Lisa manga larga",
                "Polo manga corta",
                "Estampado manga corta",
                "Lisa manga corta",
                "Deportiva manga larga",
                "Deportiva manga corta",
                "Deportiva sin mangas"
        });

        JLabel labelTalla = new JLabel("Talla:");
        comboBoxTalla = new JComboBox<>(new String[]{"S", "M", "L", "XL", "2XL"});

        JLabel labelCantidad = new JLabel("Cantidad:");
        textFieldCantidad = new JTextField();
        ((AbstractDocument) textFieldCantidad.getDocument()).setDocumentFilter(new NumericDocumentFilter(2));

        JLabel labelCodigoDiseno = new JLabel("Código de Diseño:");
        textFieldCodigoDiseno = new JTextField();
        ((AbstractDocument) textFieldCodigoDiseno.getDocument()).setDocumentFilter(new AlphanumericDocumentFilter());

        JLabel labelTipoPedido = new JLabel("Tipo de Pedido:");
        comboBoxTipoPedido = new JComboBox<>(new String[]{"Recoger en tienda", "Envío a domicilio"});
        comboBoxTipoPedido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (comboBoxTipoPedido.getSelectedItem().equals("Envío a domicilio")) {
                    textFieldDireccion.setEnabled(true);
                } else {
                    textFieldDireccion.setText("");
                    textFieldDireccion.setEnabled(false);
                }
            }
        });

        JLabel labelDireccion = new JLabel("Dirección de Entrega:");
        textFieldDireccion = new JTextField();
        textFieldDireccion.setEnabled(false);

        JLabel labelFormaPago = new JLabel("Forma de Pago:");
        comboBoxFormaPago = new JComboBox<>(new String[]{
                "Efectivo",
                "Sinpe móvil",
                "Transferencia bancaria",
                "Tarjeta de débito/crédito"
        });

        JLabel labelTelefono = new JLabel("Número Telefónico:");
        textFieldTelefono = new JTextField();
        ((AbstractDocument) textFieldTelefono.getDocument()).setDocumentFilter(new NumericDocumentFilter(8));

        JLabel labelNombre = new JLabel("Nombre Completo:");
        textFieldNombre = new JTextField();

        //Boton que hace el registro
        JButton buttonRegistrar = new JButton("Registrar Pedido");
        buttonRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    Pedido pedido = new Pedido(
                            textFieldId.getText(),
                            (String) comboBoxTipoCamiseta.getSelectedItem(),
                            (String) comboBoxTalla.getSelectedItem(),
                            textFieldCantidad.getText(),
                            textFieldCodigoDiseno.getText(),
                            (String) comboBoxTipoPedido.getSelectedItem(),
                            textFieldDireccion.getText(),
                            (String) comboBoxFormaPago.getSelectedItem(),
                            textFieldTelefono.getText(),
                            textFieldNombre.getText()
                    );
                    //Ingreso el pedido a la lista de Pedidos
                    pedidoManager.agregarPedido(pedido);
                    dispose();
                }
            }
        });

        add(labelId);
        add(textFieldId);
        add(labelTipoCamiseta);
        add(comboBoxTipoCamiseta);
        add(labelTalla);
        add(comboBoxTalla);
        add(labelCantidad);
        add(textFieldCantidad);
        add(labelCodigoDiseno);
        add(textFieldCodigoDiseno);
        add(labelTipoPedido);
        add(comboBoxTipoPedido);
        add(labelDireccion);
        add(textFieldDireccion);
        add(labelFormaPago);
        add(comboBoxFormaPago);
        add(labelTelefono);
        add(textFieldTelefono);
        add(labelNombre);
        add(textFieldNombre);
        add(buttonRegistrar);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    //Validacion de Campos
    private boolean validateFields() {
        //Determina si los campos obligatorios estan llenos
        if (textFieldCantidad.getText().isEmpty() || textFieldCodigoDiseno.getText().isEmpty() ||
                textFieldTelefono.getText().isEmpty() || textFieldNombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios, excepto Dirección de Entrega si el pedido es para recoger en tienda.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        //Valida si el campo de direccion esta lleno, si se decide el envio a Domicilio
        if (comboBoxTipoPedido.getSelectedItem().equals("Envío a domicilio") && textFieldDireccion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe proporcionar una dirección de entrega.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (textFieldTelefono.getText().length() < 8){
            JOptionPane.showMessageDialog(this, "El telefono debe ser de 8 digitos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    //Filtro para los JTextBox, este hace que solo pueda ingresar numeros y solo permitiendo un maximo de 8 caracteres
    private static class NumericDocumentFilter extends DocumentFilter {
        private int maxLength;

        public NumericDocumentFilter(int maxLength) {
            this.maxLength = maxLength;
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string == null) {
                return;
            }

            if ((fb.getDocument().getLength() + string.length()) <= maxLength && string.matches("\\d*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }

            if ((fb.getDocument().getLength() + text.length() - length) <= maxLength && text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    //Filtro para los JTextBox, este hace que solo pueda ingresar letras o numeros, no permite caracteres especiales
    private static class AlphanumericDocumentFilter extends DocumentFilter {
        private static final Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string == null) {
                return;
            }

            if (pattern.matcher(string).matches()) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }

            if (pattern.matcher(text).matches()) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}

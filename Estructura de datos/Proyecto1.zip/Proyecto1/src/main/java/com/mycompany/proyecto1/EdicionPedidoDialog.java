/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
//Librerias a utilizar
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

//Clase para la construccion de la interfaz, en caso de editar los datos
public class EdicionPedidoDialog extends JDialog {
    //Estructuras que se van a utilizar para esta clase
    private Pedido pedido;
    private PedidoManager pedidoManager;
    private JComboBox<String> tipoCamisetaCombo;
    private JComboBox<String> tallaCombo;
    private JTextField cantidadField;
    private JTextField codigoDisenoField;
    private JComboBox<String> tipoPedidoCombo;
    private JTextField direccionField;
    private JComboBox<String> formaPagoCombo;
    private JTextField telefonoField;
    private JTextField nombreField;

    // Constructor e inicializar la interfaz, este captura la fila/pedido seleccionado
    public EdicionPedidoDialog(JFrame parent, PedidoManager pedidoManager, Pedido pedido) {
        super(parent, "Editar Pedido", true);
        this.pedido = pedido;
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Diseno de la interfaz
    private void initializeUI() {
        //Se va a usar un modo con grid
        setLayout(new GridLayout(11, 2));

        //Obtencion del ID, no se puede cambiar
        add(new JLabel("ID:"));
        add(new JLabel(pedido.getId()));

        //Obtencion y posible edicion del tipo de camiseta
        add(new JLabel("Tipo de Camiseta:"));
        tipoCamisetaCombo = new JComboBox<>(new String[]{
            "Lisa manga larga", "Polo manga corta", "Estampado manga corta", "Lisa manga corta",
            "Deportiva manga larga", "Deportiva manga corta", "Deportiva sin mangas"});
        tipoCamisetaCombo.setSelectedItem(pedido.getTipoCamiseta());
        add(tipoCamisetaCombo);

        //Obtencion y posible edicion de la Talla
        add(new JLabel("Talla:"));
        tallaCombo = new JComboBox<>(new String[]{"S", "M", "L", "XL", "2XL"});
        tallaCombo.setSelectedItem(pedido.getTalla());
        add(tallaCombo);

        //Obtencion y posible edicion de la Talla, se define un maximo de 2 digitos con l filtro al JText
        add(new JLabel("Cantidad:"));
        cantidadField = new JTextField(pedido.getCantidad());
        ((AbstractDocument) cantidadField.getDocument()).setDocumentFilter(new NumericDocumentFilter(2));
        add(cantidadField);
        
        //Obtencion y posible edicion del codigo de diseno, se coloca un filtro de solo valores alfanumericos
        add(new JLabel("Código de Diseño:"));
        codigoDisenoField = new JTextField(pedido.getCodigoDiseno());
        ((AbstractDocument) codigoDisenoField.getDocument()).setDocumentFilter(new AlphanumericDocumentFilter());
        add(codigoDisenoField);

        //Obtencion y posible edicion del tipo de Pedido
        add(new JLabel("Tipo de Pedido:"));
        tipoPedidoCombo = new JComboBox<>(new String[]{"Recoger en tienda", "Envío a domicilio"});
        tipoPedidoCombo.setSelectedItem(pedido.getTipoPedido());
        //Segun lo que que suceda con este JCombobox, puede afectar a la celda de direccion
        tipoPedidoCombo.addActionListener(e -> actualizarDireccionField());
        add(tipoPedidoCombo);

        ///Direccion y si inicialmente es Tipo de Envio a domicilio se puede editar
        add(new JLabel("Dirección:"));
        direccionField = new JTextField(pedido.getDireccion());
        direccionField.setEnabled("Envío a domicilio".equals(pedido.getTipoPedido()));
        add(direccionField);

        //Obtencion y posible edicion del Tipo de Pago
        add(new JLabel("Forma de Pago:"));
        formaPagoCombo = new JComboBox<>(new String[]{"Efectivo", "Sinpe móvil", "Transferencia bancaria", "Tarjeta de débito/crédito"});
        formaPagoCombo.setSelectedItem(pedido.getFormaPago());
        add(formaPagoCombo);

        //Obtencion y Posible edicion del edicion con un filtro en el JTextBox, donde solo permite datos numericos y un maximo hasta 8
        add(new JLabel("Teléfono:"));
        telefonoField = new JTextField(pedido.getTelefono());
        ((AbstractDocument) telefonoField.getDocument()).setDocumentFilter(new NumericDocumentFilter(8));
        add(telefonoField);

        //Obtencion y Posible edicion del nombre
        add(new JLabel("Nombre Completo:"));
        nombreField = new JTextField(pedido.getNombre());
        add(nombreField);

        //Boton, para Guardar y editar los datos del Pedido
        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarCambios();
            }
        });
        add(guardarButton);

        setSize(400, 300);
        setLocationRelativeTo(getParent());
    }

    //Metodo, para en caso de cambiar el tipo de Pedido, como debe como comportarse el campo de direccion
    private void actualizarDireccionField() {
        if ("Envío a domicilio".equals(tipoPedidoCombo.getSelectedItem())){
            direccionField.setEnabled(true);
        }
        else{
            direccionField.setText("");
            direccionField.setEnabled(false);
        }
    }

    //Al dar click en guardar cambios
    private void guardarCambios() {
        // Validaciones
        String cantidad = cantidadField.getText().trim();
        String codigoDiseno = codigoDisenoField.getText().trim();
        String telefono = telefonoField.getText().trim();
        String nombre = nombreField.getText().trim();

        
        //Validacion de la cantidad de 1 a 2 decimales
        if (!cantidad.matches("\\d{1,2}")) {
            showError("Cantidad debe ser un número de 1 o 2 dígitos.");
            return;
        }

        //Validacion del codigo diseno, con solo alfanumericos sin espacio, ni especiales
        if (!codigoDiseno.matches("[a-zA-Z0-9]+")) {
            showError("Código de Diseño solo puede contener letras y números.");
            return;
        }

        //Validacion donde si o si, debe ser de 8 digitos
        if (!telefono.matches("\\d{8}")) {
            showError("Teléfono debe ser un número de 8 dígitos.");
            return;
        }
        
        //Validacion que el nombre no puede quedar vacio
        if (nombre.isEmpty()) {
            showError("Nombre no puede estar vacío.");
            return;
        }

        // Actualización de pedido
        pedido.setTipoCamiseta((String) tipoCamisetaCombo.getSelectedItem());
        pedido.setTalla((String) tallaCombo.getSelectedItem());
        pedido.setCantidad(cantidad);
        pedido.setCodigoDiseno(codigoDiseno);
        pedido.setTipoPedido((String) tipoPedidoCombo.getSelectedItem());
        pedido.setDireccion(direccionField.getText());
        pedido.setFormaPago((String) formaPagoCombo.getSelectedItem());
        pedido.setTelefono(telefono);
        pedido.setNombre(nombre);

        // Actualizar el pedido en el PedidoManager
        pedidoManager.actualizarPedido(pedido);

        //Cierre de la ventana
        dispose();
    }

    //Mensaje de Error, donde se usan los mensajes de no ingresar datos correctos
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Filtro encontrado en red, solo para numeros para los JTextBox, donde permite hasta un maximo indicado
    private static class NumericDocumentFilter extends DocumentFilter {
        private int maxLength;

        public NumericDocumentFilter(int maxLength) {
            this.maxLength = maxLength;
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string == null) {
                return;
            }

            if ((fb.getDocument().getLength() + string.length()) <= maxLength && string.matches("\\d*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }

            if ((fb.getDocument().getLength() + text.length() - length) <= maxLength && text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    //Filtro encontrado en red, para JTextBox, que solo valores alfanumericos, los cuales no contienen espacios ni caracteres especiales
    private static class AlphanumericDocumentFilter extends DocumentFilter {
        private static final Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string == null) {
                return;
            }

            if (pattern.matcher(string).matches()) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }

            if (pattern.matcher(text).matches()) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}
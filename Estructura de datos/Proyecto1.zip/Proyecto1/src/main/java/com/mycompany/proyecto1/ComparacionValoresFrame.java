/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
//Librerias a utilizar
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Metodo principal para generar la ventana de comparar valores
public class ComparacionValoresFrame extends JFrame {
    //Estructuras que se van a usar para esta clase
    private PedidoManager pedidoManager;
    private JLabel labelIdPedido;
    private JTextField textFieldIdPedido;
    private JTextArea textAreaResultado;
    
    // Constructor e inicilizador de la ventana de Comparar Valores
    public ComparacionValoresFrame(PedidoManager pedidoManager) {
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Diseno de Interfaz
    private void initializeUI() {
        //Bloque de la interfaz
        setTitle("Comparación de Valores");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        //Se va a usar en forma paneles
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 10, 10, 10);

        // Etiqueta y campo de texto para ingresar el ID del pedido
        labelIdPedido = new JLabel("ID del pedido:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(labelIdPedido, constraints);

        textFieldIdPedido = new JTextField(15);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.weightx = 0.5;
        panel.add(textFieldIdPedido, constraints);

        // Botón para realizar la comparación
        JButton buttonComparar = new JButton("Comparar");
        buttonComparar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                compararValores();
            }
        });
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(buttonComparar, constraints);

        // Área de texto para mostrar el resultado
        textAreaResultado = new JTextArea(12, 30); // Aumenta el número de filas para dar más espacio vertical
        textAreaResultado.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textAreaResultado);
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.weighty = 1.0;
        panel.add(scrollPane, constraints);

        getContentPane().add(panel, BorderLayout.CENTER);
    }

    //Metodo para comparar valores
    private void compararValores() {
        String idPedidoStr = textFieldIdPedido.getText().trim();
        
        //Error de no ingresar ningun valor
        if (idPedidoStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID de pedido válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        //Error de no ingresar un valor que no pertenece a la lista de Id
        int idPedido = Integer.parseInt(idPedidoStr);
        Pedido pedido = pedidoManager.buscarPorId(idPedido);

        if (pedido == null) {
            JOptionPane.showMessageDialog(this, "No se encontró un pedido con el ID especificado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String cantidad = pedido.getCantidad();
        int cantidadDecimal = Integer.parseInt(cantidad);

        // Obtener valor binario utilizando recursividad
        String cantidadBinaria = convertirABinario(cantidadDecimal);

        // Mostrar resultado en el área de texto
        textAreaResultado.setText("ID del pedido: " + idPedido + "\n"
                + "Cantidad decimal: " + cantidadDecimal + "\n"
                + "Valor binario: " + cantidadBinaria);
    }

    //Funcion de recursividad para convertir decimal a binario
    private String convertirABinario(int numero) {
        if (numero == 0) {
            return "0";
        } else if (numero == 1) {
            return "1";
        } else {
            int residuo = numero % 2;
            int cociente = numero / 2;
            return convertirABinario(cociente) + residuo;
        }
    }
}
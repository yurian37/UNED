/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

//Funcion que da la interfaz de la selccion de Ordenamiento
public class OrdenamientoPedidosFrame extends JFrame {

    private PedidoManager pedidoManager;
    private JTable tablaPedidos;
    private JComboBox<String> comboBoxOrdenamiento;

    // Inicializacion de la Interfaz
    public OrdenamientoPedidosFrame(PedidoManager pedidoManager) {
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Diseno de la inetrfaz de Usuario
    private void initializeUI() {
        setTitle("Ordenamiento de Pedidos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana

        JPanel panel = new JPanel(new BorderLayout());

        // Panel para opciones de ordenamiento
        JPanel panelOpciones = new JPanel();
        panelOpciones.add(new JLabel("Ordenar por:"));

        //Se ingresan los dos tipos de Ordenamiento en un ComboBox
        comboBoxOrdenamiento = new JComboBox<>(new String[]{"Número telefónico ascendente", "Código de diseño descendente"});
        panelOpciones.add(comboBoxOrdenamiento);

        //Boton para iniciar el proceso de Ordenamiento
        JButton buttonOrdenar = new JButton("Ordenar");
        buttonOrdenar.addActionListener(e -> ordenarPedidos());
        panelOpciones.add(buttonOrdenar);

        panel.add(panelOpciones, BorderLayout.NORTH);

        // Tabla para mostrar los pedidos de forma ordenada escogida
        tablaPedidos = new JTable();
        JScrollPane scrollPane = new JScrollPane(tablaPedidos);
        panel.add(scrollPane, BorderLayout.CENTER);

        getContentPane().add(panel);

        // Mostrar la ventana
        setVisible(true);
    }

    //Funciones de Ordenamiento
    private void ordenarPedidos() {
        String opcionOrdenamiento = (String) comboBoxOrdenamiento.getSelectedItem();
        // Convertir ArrayList a array
        Pedido[] pedidosArray = pedidoManager.getPedidos().toArray(new Pedido[0]); 

        //Decision del tipo de Ordenamiento
        switch (opcionOrdenamiento) {
            case "Número telefónico ascendente":
                ordenarPorNumeroTelefonoAscendente(pedidosArray);
                break;
            case "Código de diseño descendente":
                ordenarPorCodigoDisenoDescendente(pedidosArray);
                break;
        }

        //Mostra el Array
        mostrarEnTabla(pedidosArray);
    }
    
    //Ordenamiento a Telefono usando algoritmo por insercion
    private void ordenarPorNumeroTelefonoAscendente(Pedido[] pedidos) {
        for (int i = 1; i < pedidos.length; i++) {
            Pedido current = pedidos[i];
            int j = i - 1;

            // Comparar los teléfonos para determinar el orden
            while (j >= 0 && pedidos[j].getTelefono().compareTo(current.getTelefono()) > 0) {
                pedidos[j + 1] = pedidos[j];
                j--;
            }
            pedidos[j + 1] = current;
        }
    }
    
    //Ordenamiento por el Codigo Diseno descendente usando algoritmo de merge sort
    public static void ordenarPorCodigoDisenoDescendente(Pedido[] pedidos) {
        if (pedidos == null || pedidos.length < 2) {
            return;
        }
        mergeSort(pedidos, 0, pedidos.length - 1);
    }

    //Definicion del metodo mergesort
    private static void mergeSort(Pedido[] pedidos, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(pedidos, left, mid);
            mergeSort(pedidos, mid + 1, right);
            merge(pedidos, left, mid, right);
        }
    }

    // Realizando procesos del merge
    private static void merge(Pedido[] pedidos, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Pedido[] leftArray = new Pedido[n1];
        Pedido[] rightArray = new Pedido[n2];

        System.arraycopy(pedidos, left, leftArray, 0, n1);
        System.arraycopy(pedidos, mid + 1, rightArray, 0, n2);

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2) {
            if (leftArray[i].getCodigoDiseno().compareTo(rightArray[j].getCodigoDiseno()) >= 0) {
                pedidos[k] = leftArray[i];
                i++;
            } else {
                pedidos[k] = rightArray[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            pedidos[k] = leftArray[i];
            i++;
            k++;
        }

        while (j < n2) {
            pedidos[k] = rightArray[j];
            j++;
            k++;
        }
    }
    
    //Diseño de la tabla que se mostrara.
    private void mostrarEnTabla(Pedido[] pedidos) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Tipo Camiseta");
        model.addColumn("Talla");
        model.addColumn("Cantidad");
        model.addColumn("Código Diseño");
        model.addColumn("Tipo Pedido");
        model.addColumn("Dirección");
        model.addColumn("Forma Pago");
        model.addColumn("Teléfono");
        model.addColumn("Nombre");

        for (Pedido pedido : pedidos) {
            model.addRow(new String[]{
                    pedido.getId(),
                    pedido.getTipoCamiseta(),
                    pedido.getTalla(),
                    pedido.getCantidad(),
                    pedido.getCodigoDiseno(),
                    pedido.getTipoPedido(),
                    pedido.getDireccion(),
                    pedido.getFormaPago(),
                    pedido.getTelefono(),
                    pedido.getNombre()
            });
        }

        tablaPedidos.setModel(model);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.Iterator;

//Aqui se van a mostrar todos los pedidos
public class ListaPedidosFrame extends JFrame {
    private PedidoManager pedidoManager;
    private JTable tablePedidos;

    //Inicio de la interfaz de la lista de Pedidos
    public ListaPedidosFrame(PedidoManager pedidoManager) {
        this.pedidoManager = pedidoManager;
        initializeUI();
    }

    //Definicion de la interfaz
    private void initializeUI() {
        setTitle("Listado de Pedidos");
        setSize(800, 600);

        // Obtener los datos de los pedidos y estructura de la tabla
        PedidoTableModel tableModel = new PedidoTableModel(pedidoManager.listarPedidos());
        tablePedidos = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tablePedidos);

        getContentPane().add(scrollPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    // Modelo de tabla personalizado para los pedidos
    private static class PedidoTableModel extends AbstractTableModel {
        private static final String[] COLUMNAS = {"ID", "Tipo de Camiseta", "Talla", "Cantidad", "Código de Diseño",
                                                  "Tipo de Pedido", "Dirección", "Forma de Pago", "Teléfono", "Nombre"};
        private static final int NUM_COLUMNAS = COLUMNAS.length;
        private Object[][] data;

        public PedidoTableModel(Iterable<Pedido> pedidos) {
            data = new Object[calcularNumFilas(pedidos)][NUM_COLUMNAS];
            int row = 0;
            for (Pedido pedido : pedidos) {
                data[row][0] = pedido.getId();
                data[row][1] = pedido.getTipoCamiseta();
                data[row][2] = pedido.getTalla();
                data[row][3] = pedido.getCantidad();
                data[row][4] = pedido.getCodigoDiseno();
                data[row][5] = pedido.getTipoPedido();
                data[row][6] = pedido.getDireccion();
                data[row][7] = pedido.getFormaPago();
                data[row][8] = pedido.getTelefono();
                data[row][9] = pedido.getNombre();
                row++;
            }
        }

        //Segun la cantidad de Pedidos, calcular el numero de filas para iterar en la lista
        private int calcularNumFilas(Iterable<Pedido> pedidos) {
            int count = 0;
            Iterator<Pedido> iterator = pedidos.iterator();
            while (iterator.hasNext()) {
                iterator.next();
                count++;
            }
            return count;
        }

        @Override
        public int getRowCount() {
            return data.length;
        }

        @Override
        public int getColumnCount() {
            return NUM_COLUMNAS;
        }

        @Override
        public String getColumnName(int column) {
            return COLUMNAS[column];
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            return data[rowIndex][columnIndex];
        }
    }
}


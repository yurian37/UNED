/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;

/* UNED II Cuatrimestre 2024
 * * Proyecto01: Aplicacion Empresa XDesign
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 19/06/2024
 * 
 * */
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

//Clase que ayuda a la busqueda y edicion de Pedidos
public class PedidoTableModel extends AbstractTableModel {
    private List<Pedido> pedidos;
    private String[] columnNames = {"ID", "Tipo Camiseta", "Talla", "Cantidad", "Código Diseño", "Tipo Pedido", "Dirección", "Forma Pago", "Teléfono", "Nombre"};

    public PedidoTableModel() {
        this.pedidos = new ArrayList<>();
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
        fireTableDataChanged();
    }

    public Pedido getPedidoAt(int rowIndex) {
        return pedidos.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return pedidos.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Pedido pedido = pedidos.get(rowIndex);
        switch (columnIndex) {
            case 0: return pedido.getId();
            case 1: return pedido.getTipoCamiseta();
            case 2: return pedido.getTalla();
            case 3: return pedido.getCantidad();
            case 4: return pedido.getCodigoDiseno();
            case 5: return pedido.getTipoPedido();
            case 6: return pedido.getDireccion();
            case 7: return pedido.getFormaPago();
            case 8: return pedido.getTelefono();
            case 9: return pedido.getNombre();
            default: return null;
        }
    }
}


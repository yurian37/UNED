/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto3;

/**
 *
 * @author pabloa1x
 */
import javax.swing.*;
import java.awt.*;

public class ArbolBinario {
    private Nodo raiz;

    // Constructor
    public ArbolBinario() {
        this.raiz = null;
    }
    
    public Nodo getRaiz(){
        return raiz;
    }
    

    // Método para insertar una impresora en el árbol
    public boolean insertar(Impresora impresora) {
        if (buscar(impresora.getId())) {
            return false; // ID duplicado, no se inserta
        }
        raiz = insertarRecursivo(raiz, impresora);
        return true; // Inserción exitosa
    }

    private Nodo insertarRecursivo(Nodo nodo, Impresora impresora) {
        if (nodo == null) {
            return new Nodo(impresora);
        }

        if (impresora.getId() < nodo.getImpresora().getId()) {
            nodo.setIzquierdo(insertarRecursivo(nodo.getIzquierdo(), impresora));
        } else if (impresora.getId() > nodo.getImpresora().getId()) {
            nodo.setDerecho(insertarRecursivo(nodo.getDerecho(), impresora));
        }

        return nodo;
    }

    // Método para verificar si un ID ya existe en el árbol
    private boolean idExiste(Nodo nodo, int id) {
        if (nodo == null) {
            return false;
        }

        if (id == nodo.getImpresora().getId()) {
            return true;
        } else if (id < nodo.getImpresora().getId()) {
            return idExiste(nodo.getIzquierdo(), id);
        } else {
            return idExiste(nodo.getDerecho(), id);
        }
    }
    
    // Método para eliminar una impresora del árbol por ID
    public boolean eliminar(int id) {
    if (!buscar(id)) {
        return false; // ID no encontrado
    }
    raiz = eliminarRecursivo(raiz, id);
    return true; // Eliminación exitosa
}

    private Nodo eliminarRecursivo(Nodo nodo, int id) {
        if (nodo == null) {
            return null; // ID no encontrado
        }

        if (id < nodo.getImpresora().getId()) {
            nodo.setIzquierdo(eliminarRecursivo(nodo.getIzquierdo(), id));
        } else if (id > nodo.getImpresora().getId()) {
            nodo.setDerecho(eliminarRecursivo(nodo.getDerecho(), id));
        } else {
            // Nodo encontrado
            if (nodo.getIzquierdo() == null && nodo.getDerecho() == null) {
                return null; // Nodo hoja
            } else if (nodo.getIzquierdo() == null) {
                return nodo.getDerecho(); // Solo un hijo derecho
            } else if (nodo.getDerecho() == null) {
                return nodo.getIzquierdo(); // Solo un hijo izquierdo
            } else {
                // Nodo con dos hijos
                JOptionPane.showMessageDialog(null, "No se puede eliminar el nodo porque tiene 2 hijos.", "Error", JOptionPane.ERROR_MESSAGE);
                return nodo; // No se elimina, retorna el nodo original
        }
    }
    return nodo; // Retorna el nodo actualizado
}
    
    // Método para buscar una impresora por ID y que retorne booleano
    private boolean buscar(int id) {
        return buscarRecursivo(raiz, id);
    }

    private boolean buscarRecursivo(Nodo nodo, int id) {
        if (nodo == null) {
            return false;
        }
        if (nodo.getImpresora().getId() == id) {
            return true; // ID encontrado
        }
        return buscarRecursivo(nodo.getIzquierdo(), id) || buscarRecursivo(nodo.getDerecho(), id);
    }
    
    //Método para buscar una impresora por ID y que retorne la impresora
    public Impresora buscar_impresora(int id) {
        return buscarRecursivo_impresora(raiz, id);
    }

    private Impresora buscarRecursivo_impresora(Nodo nodo, int id) {
        if (nodo == null) {
            return null; // ID no encontrado
    }

        if (nodo.getImpresora().getId() == id) {
            return nodo.getImpresora(); // ID encontrado, retornar la impresora
        } else if (id < nodo.getImpresora().getId()) {
            return buscarRecursivo_impresora(nodo.getIzquierdo(), id); // Buscar en el subárbol izquierdo
        } else {
            return buscarRecursivo_impresora(nodo.getDerecho(), id); // Buscar en el subárbol derecho
        }
    }
}



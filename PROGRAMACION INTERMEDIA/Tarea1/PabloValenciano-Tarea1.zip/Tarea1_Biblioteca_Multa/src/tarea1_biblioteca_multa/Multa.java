/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea1_biblioteca_multa;

import java.util.Scanner;

public class Multa{
    
    Scanner entrada = new Scanner(System.in);
    //Input Values
    private String username;
    private String name;
    private String book_name;
    private String author_book;
    private double mount_book;
    private int delay_days;
    
    //Second Phase
    private double fine_mount;
    
    //Metodo que captura el usuario debe ser entre 9 a 15 caracteres, de otro modo se vuelve a pedir
    public void set_username(){
        System.out.println("El usuario a ingresar debe ser de entre 9 a 15 caracteres");
        //System.out.println("Ingrese una cadena de texto (entre 9 y 15 caracteres):");
        username = entrada.nextLine();
        if (username.length() >= 9 && username.length() <=15){
            System.out.println("Usuario con extension adecuada\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
        }
        else {
            System.out.println("Usuario con extension inadecuada digite otro para continuar");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_username();
        }
    }
    //Metodo que captura el nombre debe ser no nulo y maximo 30 caracteres, de otro modo se vuelve a pedir
    public void set_name(){
        System.out.println("Digite el nombre como un maximo de 30 caracteres:");
        //System.out.println("Ingrese una cadena de texto de maximo 30 caracteres:");
        name = entrada.nextLine();
        if (name.length() > 0 && name.length() <=30){
            System.out.println("Nombre con extension adecuada\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
        }
        else {
            System.out.println("Nombre con extension inadecuada digite otro para continuar\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_name();
        }
    }
    //Metodo que captura el nombre del libro debe ser no nulo y maximo 60 caracteres, de otro modo se vuelve a pedir
    public void set_bookname(){
        System.out.println("Nombre del libro maximo de 60 caracteres:");
        //System.out.println("Ingrese una cadena de texto maximo de 60 caracteres:");
        book_name = entrada.nextLine();
        if (book_name.length() > 0 && book_name.length() <=60){
            System.out.println("Nombre del libro con extension adecuada\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
        }
        else {
            System.out.println("Nombre del libro con extension inadecuada digite otro para continuar\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_bookname();
        }
    }
    //Metodo que captura el autor del libre debe ser entre 15 a 40 caracteres, de otro modo se vuelve a pedir
    public void set_authorname(){
        System.out.printf("Inserte el autor del libro %s debe ser entre 15 y 40 caracteres:%n", book_name);
        //System.out.println("Ingrese una cadena de texto (entre 15 y 40 caracteres):");
        author_book = entrada.nextLine();
        if (author_book.length() >= 15 && author_book.length() <=40){
            System.out.println("Autor con extension adecuada\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
        }
        else {
            System.out.println("Autor con extension inadecuada digite otro para continuar\n");
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_authorname();
        }
    }
    //Metodo que captura el monto del libro debe ser un numero y este debe ser mayor a 1000 y puede ser decimal, sino se vuelve a pedir
    public void set_mountbook(){
        System.out.printf("Ingrese el monto del libro %s el cual debe ser 1000 o mayor:%n", book_name);
        //System.out.println("Ingrese un numero mayor o igual a mil:");
        if(entrada.hasNextDouble()){
            mount_book=entrada.nextDouble();
            if(mount_book>=1000){
                System.out.println("Monto adecuado\n");
                entrada.nextLine();
                //System.out.println("Presione Enter para continuar...");
                //entrada.nextLine();
            }
            else{
                System.out.println("Monto inadecuado digite otro\n");
                entrada.nextLine();
                //System.out.println("Presione Enter para continuar...");
                //entrada.nextLine();
                set_mountbook();
            }
        }
        else{
            System.out.println("Monto no es numerico digite otro\n");
            entrada.nextLine();
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_mountbook();
        }
    }
    //Metodo que captura los dias de retraso, en caso de entregr antes se digita 0, este debe ser positivo y entero de otro modo se vuelve a pedir.
    public void set_delaydays(){
        System.out.printf("Ingrese el numero de dias en enteros el cual %s se retraso a entregar %s:%n",username,book_name);
        if(entrada.hasNextInt()){
            delay_days=entrada.nextInt();
            if(delay_days>=0){
                System.out.println("Dias adecuado\n");
                entrada.nextLine();
                //System.out.println("Presione Enter para continuar...");
                //entrada.nextLine();
            }
            else{
                System.out.println("Dias negativos no valido digite otro\n");
                entrada.nextLine();
                //System.out.println("Presione Enter para continuar...");
                //entrada.nextLine();
                set_delaydays();
            }
        }
        else{
            System.out.println("Monto no es numerico digite otro\n");
            entrada.nextLine();
            //System.out.println("Presione Enter para continuar...");
            //entrada.nextLine();
            set_delaydays();
        }
    }
    /*Metodo que calcula multa, segun la tabla del pdf 0 dias-> 0 Multa, 1 a 7 dias -> 3% del monto del libro, 8 a 15 dias -> 10% del monto del libro,
    16 a 30 dias -> 20% del monto del libro, 31 a 45 dias -> 35% del monto del libro, +45 dias -> 50% del monto del libro
    */
    public void CalcularMulta(){
        if(delay_days==0){
            fine_mount=0;
        }
        else{
            if(delay_days<=7){
                fine_mount=mount_book*0.03;
            }
            else{
                if(delay_days<=15){
                    fine_mount=mount_book*0.1;
                }
                else{
                    if(delay_days<=30){
                        fine_mount=mount_book*0.2;
                    }
                    else{
                        if(delay_days<=45){
                            fine_mount=mount_book*0.35;
                        }
                        else{
                            fine_mount=mount_book*0.5;
                        }
                    }
                }
            }
        }
        //Impresion de la multa
        System.out.printf("El monto a cobrar es %.2f%n", fine_mount);
    }
    
    //Conjunto de metodos para obtener las variables de la clase
    public String get_username(){
        return username;
    }
    
    public String get_name(){
        return name;
    }
    
    public String get_bookname(){
        return book_name;
    }
    
    public String get_authorname(){
        return author_book;
    }
    
    public double get_mountbook(){
        return mount_book;
    }
    
    public int get_delaydays(){
        return delay_days;
    }
    
    public double get_multa(){
        return fine_mount;
    }
}

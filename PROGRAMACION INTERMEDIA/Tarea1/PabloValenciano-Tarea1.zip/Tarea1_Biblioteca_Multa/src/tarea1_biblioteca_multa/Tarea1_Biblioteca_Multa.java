/*
Como desarrollador en Java se la ha asignado encargado elaborar una aplicación 
para calcular la multa que deben pagar las personas que no regresan los libros 
a tiempo en una tienda de alquiler de libros.
*/
package tarea1_biblioteca_multa;

/**
 *
 * @author Pablo Valenciano
 */

//Librerias de Insercion de data y uso de arreglos
import java.util.ArrayList;
import java.util.Scanner;


//Clase General
public class Tarea1_Biblioteca_Multa {
    //Metodo que digita una line de 20 "-" se usa para separar
    public static void crearlinea(){
        for (int i = 0; i < 20; i++) {
            System.out.print("-");
        }
        System.out.println(); // Salto de línea después de imprimir la línea de "-"
    }
    //Metodo de control que requiere insercion del usuario de S/N o en otro caso vuelve a preguntar
    public static boolean seguir(){
        //Se crea la variable para solicitar a usuario
        Scanner entrada = new Scanner(System.in);
        //Se inicializa la variable
        boolean response=true;
        //Variable que captura el dato
        String decision;
        System.out.printf("Deseas continuar S/N: %n");
        //Captura lo ingresado por el usuario
        decision=entrada.nextLine();
        //Si se escribe N, se retorna a false, usando un str cmp, para futuros programas se habilita la opcion de n minuscula
        if ("N".equals(decision) /*|| "n".equals(decision)*/){
            response=false;
        }
        else{
            //Si se escribe S, el programa continua, se puede habilitar el programa para que s minuscula tambien valga
            if ("S".equals(decision) /*|| "s".equals(decision)*/){
                response=true;
            }
            // Si se escribe algo diferente a S/N se vuelve a preguntar
            else{
                System.out.printf("No se escogio opcion valida %n");
                seguir();
            }
        }
        return response;
    }
    //Metodo que retorna la lista con la informacion de usuario, libro y las multas por cada transaccion. Parametros arreglos con toda la informacion y un encabezado para la tabla
    public static void mostrar(ArrayList<Multa> all_multas, String encabezado){
        System.out.printf("%s%n",encabezado);
        System.out.printf("%15s|%30s|%60s|%40s|%20s|%20s|%15s|%n","Usuario"
                ,"Nombre del Usuario","Nombre del Libro","Autor del Libro",
                "Monto del Libro","Dias de retraso","Monto de Multa");
        //Impresion de todos los datos del arreglo, no hay try, ya que el do while se completa al menos 1 vez, por lo que el caso 0 no existe
        for (Multa each_multa : all_multas){
            System.out.printf("%15s|%30s|%60s|%40s|%20.2f|%20d|%15.2f|%n",each_multa.get_username()
                ,each_multa.get_name(),each_multa.get_bookname(),each_multa.get_authorname(),
                each_multa.get_mountbook(),each_multa.get_delaydays(),each_multa.get_multa());
        }    
    }
    //Metodo que suma las multas e imprime su resultado
    public static void calcular_total(ArrayList<Multa> elementos){
        double total=0;
        for(Multa elemento : elementos){
            total += elemento.get_multa();
        }
        System.out.printf("El total de multas es: %10.2f %n", total);
    }
    //Metodo que calcula promedio de las multas, no hay try catch ya que al usar do while, este debe ser exitoso 1 vez
    public static void calcular_promedio(ArrayList<Multa> elementos){
        double total=0;
        int contador=0;
        for(Multa elemento : elementos){
            total += elemento.get_multa();
            contador++;
        }
        System.out.printf("El promedio de las multas es: %10.2f %n", (double) total/contador);
    }
    //Metido que atrapa la mayor multa e imprime cual fue, en caso de haber mas de una multa con la misma multa, solo imprime la primera encontrada 
    public static void calcular_mayor(ArrayList<Multa> elementos){
        double monto_mayor=0;
        String usuario_mayor="";
        String libro_mayor="";
        for(Multa elemento : elementos){
            if (elemento.get_multa()>monto_mayor){
                monto_mayor=elemento.get_multa();
                usuario_mayor=elemento.get_username();
                libro_mayor=elemento.get_bookname();
            }
        }
        System.out.printf("La mayor multa es por el usuario %s en el libro %s el cual es de: %.2f %n",usuario_mayor,libro_mayor,monto_mayor);
    }
    /**
     * Funcion main
     * @param args
     */
    //Metodo main, metodo que se ejecuta al iniciar el programa
    public static void main(String[] args) {
        //Declaracion de variables
        boolean continuar;
        ArrayList<Multa> multas = new ArrayList<>();
        do{
            //Variable que crea una nueva multa, cada vez que se reingresa
            Multa mi_multa= new Multa();
            crearlinea();
            //Insercion de usuario
            System.out.println("Digita el usuario\n");
            mi_multa.set_username();
            crearlinea();
            //Insercion de nombre real del usuario
            System.out.println("Digita el nombre de la persona que devuelve\n");
            mi_multa.set_name();
            crearlinea();
            //Insercion de nombre del Libro
            System.out.println("Digita el nombre del libro\n");
            mi_multa.set_bookname();
            crearlinea();
            //Insercion del autor de libro
            System.out.println("Digita el nombre del autor\n");
            mi_multa.set_authorname();
            crearlinea();
            //Insercion del costo de Libro
            System.out.println("Digita el costo del libro\n");
            mi_multa.set_mountbook();
            crearlinea();
            //Insercion de cuantos dias se retraso.
            System.out.println("Digita el numero de dias de atraso\n");
            mi_multa.set_delaydays();
            crearlinea();
            //Metodo de la clase Multa, que calcula el monto de la multa
            mi_multa.CalcularMulta();
            //Impresion que da informacion recien ingresada, se retira ya que no es lo solicitado
            /*System.out.printf("%15s|%30s|%60s|%40s|%8.2f|%5d|%10.2f|%n",mi_multa.get_username()
                ,mi_multa.get_name(),mi_multa.get_bookname(),mi_multa.get_authorname(),
                mi_multa.get_mountbook(),mi_multa.get_delaydays(),mi_multa.get_multa());
                */
            //Insercion de la multa al arreglo en la ultima posicion
            multas.add(mi_multa);
            //Cuestinomiento que retorna true/false si desea continuar agregando multas
            continuar = seguir();
        }while(continuar); //Si es false sale del ciclo
        //Metodo que imprime las multas con formato
        mostrar(multas,"Registro de Multas");
        //Metodo que da informacion del total de multas registradas
        calcular_total(multas);
        //Metodo que calcula el promedio de las multas
        calcular_promedio(multas);
        //Metodo que calcula la mayor multa registrada
        calcular_mayor(multas);
    }
}

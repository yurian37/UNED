/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 *
 * @author pvale
 */

//Clase para la estructura de la lista resumida
public class DataEntry_Summary {
    private final StringProperty column1Value = new SimpleStringProperty();
    private final StringProperty column2Value = new SimpleStringProperty();
    
    //Constructor de la clase
    public DataEntry_Summary(String column1Value, String column2Value) {
        setColumn1Value(column1Value);
        setColumn2Value(column2Value);
    }
    //Funcion que retorna el valor de cada columna
    public String getColumn1Value() {
        return column1Value.get();
    }
    //Funcion que permite cambiar el valor
    public void setColumn1Value(String value) {
        column1Value.set(value);
    }
    //Funcion que retorna el tipo de clase de cada columna
    public StringProperty column1ValueProperty() {
        return column1Value;
    }

    public String getColumn2Value() {
        return column2Value.get();
    }

    public void setColumn2Value(String value) {
        column2Value.set(value);
    }

    public StringProperty column2ValueProperty() {
        return column2Value;
    }
}

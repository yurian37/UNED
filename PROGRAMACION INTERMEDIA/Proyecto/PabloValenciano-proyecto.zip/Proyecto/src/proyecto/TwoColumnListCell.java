/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author pvale
 */
import javafx.scene.control.ListCell;
//Funcion que ordena la informacion la tabla detallada
public class TwoColumnListCell extends ListCell<DataEntry_Summary> {
    @Override
    protected void updateItem(DataEntry_Summary item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setText(null);
        } else {
            setText(item.getColumn1Value() + " | " + item.getColumn2Value());
        }
    }
}

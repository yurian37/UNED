/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import javafx.scene.control.ListCell;

/**
 *
 * @author pvale
 */
//Clase que ordena la informacion de la clase detallada
public class EightColumnListCell extends ListCell<DataEntry_Detailed>{
    @Override
    protected void updateItem(DataEntry_Detailed item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setText(null);
        } else {
            setText(item.getColumn1Value() + " | " + item.getColumn2Value() 
                    + " | " + item.getColumn3Value() + " | " + item.getColumn4Value() 
                    + " | " + item.getColumn5Value() + " | " + item.getColumn6Value()
                    + " | " + item.getColumn7Value() + " | " + item.getColumn8Value());
        }
    }
    
}

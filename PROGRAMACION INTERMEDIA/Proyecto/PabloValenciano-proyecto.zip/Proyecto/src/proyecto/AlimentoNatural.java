/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author pvale
 */

//Clase heredada de Aliemnto, conocida como Alimento Natural
public class AlimentoNatural extends Alimento {
    //Variable agregada
    public String Tipo_Alimento;
    
    //Constructor de alimento natural
    public AlimentoNatural(String codigo, String nameFood,
            double proteina, double carbohidratos, 
            double grasas, LocalDate fechaCreacion, 
            String Tipo_Alimento){
        super(codigo,nameFood,proteina,carbohidratos, grasas, fechaCreacion);
        this.Tipo_Alimento = Tipo_Alimento;
    }
    
    //Funcion que retorna de tipo string al construir la variable
    @Override
    public String toString(){
        return String.format("Alimento: Natural%n"
                + "Codigo: %s%n"
                + "Nombre: %s%n"
                + "Proteina c/100g: %.2f%n"
                + "Carbohidratos c/100g: %.2f%n"
                + "Grasa c/100g: %.2f%n"
                + "Fecha: %s%n"
                + "Adicional: %s%n"
                ,super.codigo,super.nameFood,
                super.proteina,super.carbohidratos,super.grasas,
                super.fechaCreacion.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                Tipo_Alimento);
    }
}

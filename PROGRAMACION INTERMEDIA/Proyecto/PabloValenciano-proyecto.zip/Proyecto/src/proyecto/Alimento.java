/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package proyecto;

import java.time.LocalDate;
import java.util.InputMismatchException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
/**
 *
 * @author pvale
 */

//Clase Principal Alimento
public class Alimento {
    //Variables de uso´para heredar
    public String codigo;
    public String nameFood;
    public double proteina;
    public double carbohidratos;
    public double grasas;
    public LocalDate fechaCreacion;
    
    //Constructor
    public Alimento(String codigo, String nameFood,
            double proteina, double carbohidratos, 
            double grasas, LocalDate fechaCreacion
    ) {
        try{
            this.codigo = codigo;
            this.nameFood = nameFood;
            this.proteina = proteina;
            this.carbohidratos = carbohidratos;
            this.grasas = grasas;
            this.fechaCreacion = fechaCreacion;
        }
        catch(InputMismatchException e) {
            //Error del constructor no completo
            mostrarAlerta("Error Insercion","La data ingresada no es la correcta",AlertType.ERROR);
        }
    }
    
    //Funcion para alertas.
    private void mostrarAlerta(String titulo, String mensaje, AlertType tipo){
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;




/**
 *
 * @author pvale
 */

//Funcion principañ
public class Proyecto extends Application {
    //Funcion que permite crear archivo, si este no existe
    public static void CrearArchivo(String nombre_archivo){
        File archivo = new File(nombre_archivo);
        
        if(!archivo.exists()){
            try{
                archivo.createNewFile();
            }
            catch (IOException e){
            }
        }
    }
    //Funcion que refiere a la aplicacion GUI
    @Override
    public void start(Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Proyecto.fxml"));
        Scene scene = new Scene(root);
        
        stage.setTitle("Proyecto");
        
        stage.setScene(scene);
        stage.show();
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Crea el archivo Alimentos.txt
        CrearArchivo("Alimentos.txt");
        //Crea archivo AlimentoEliminados.txt
        CrearArchivo("AlimentosEliminados.txt");
        //Genera la interfaz
        launch(args);
    }
    
    
    
}

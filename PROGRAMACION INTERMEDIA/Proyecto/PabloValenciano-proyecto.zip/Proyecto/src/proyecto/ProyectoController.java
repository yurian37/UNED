/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.TextFormatter;
import javafx.util.converter.DoubleStringConverter;

import java.time.LocalDate;
import javafx.util.StringConverter;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import javafx.scene.input.MouseEvent;


/**
 *
 * @author pvale
 */
public class ProyectoController {
    //Declaracion de los elementos de la interfaz
    @FXML
    private Button AddButton;

    @FXML
    private Tab AddTab;

    @FXML
    private TextField InputAdditionalTextbox;

    @FXML
    private Label InputLabelAddaptable;

    @FXML
    private TextField InputcarbohidratosTextbox;

    @FXML
    private TextField InputcodeTextbox;

    @FXML
    private DatePicker Inputdate;

    @FXML
    private ComboBox<String> InputfoodCombobox;

    @FXML
    private TextField InputgrasaTextbox;

    @FXML
    private TextField InputnameTextbox;

    @FXML
    private TextField InputproteinasTextbox;

    @FXML
    private Tab ModRemTab;

    @FXML
    private Button ModifyButton;

    @FXML
    private TextField ModifyCarbohidratosTextbox;

    @FXML
    private ListView<DataEntry_Summary> ModifySummaryList;

    @FXML
    private TextField ModifyadditionalTextbox;

    @FXML
    private TextField ModifycodeTextbox;

    @FXML
    private DatePicker ModifydateTextbox;

    @FXML
    private TextField ModifygrasaTextbox;

    @FXML
    private TextField ModifynameTextbox;

    @FXML
    private TextField ModifyproteinasTextbox;

    @FXML
    private Button RemoveButton;

    @FXML
    private DatePicker SearchDate;

    @FXML
    private ListView<DataEntry_Detailed> SearchListDetailed;

    @FXML
    private Tab SearchTab;

    @FXML
    private Button SearchcodeButton;

    @FXML
    private TextField SearchcodeTextbox;

    @FXML
    private Button SearchdateButton;

    @FXML
    private Button WelcomeButton;

    @FXML
    private Tab WelcomeTab;
    
    @FXML
    private TabPane TP;
    
    //Listas que agrupan ciertos elementos de cada Tab
    @FXML
    private List<TextField> textInputFields = new ArrayList<>();
    
    @FXML
    private List<TextField> textModifyFields = new ArrayList<>();
    //Lista que agrupa los elementos que usan fecha
    @FXML
    private List<DatePicker> Date_List = new ArrayList<>();
    
    //Listas usadas para ser la linea de buses de los datos
    private List<String> List_Alimentos = new ArrayList<>();
    private List<String> List_Codigos = new ArrayList<>();
    private List<String> List_Nombres = new ArrayList<>();
    private List<String> List_Proteinas = new ArrayList<>();
    private List<String> List_Carbohidratos = new ArrayList<>();
    private List<String> List_Grasas = new ArrayList<>();
    private List<String> List_Dates = new ArrayList<>();
    private List<String> List_Additional = new ArrayList<>();

    //Funcion para generar alerta
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    //Funcion que revissa si un arregle de Textbox esten todos completos
    private boolean checkAllFieldsFilled(TextField... textFields) {
        for (TextField textField : textFields) {
            if (textField.getText().trim().isEmpty()) {
                return false;
            }
        }
        return true;
    }
    //Funcion que revissa si un arregle de DatePicker esten todos completos
     private boolean checkAllDatePicker(DatePicker... datePickers) {
        for (DatePicker datePicker : datePickers) {
            if (datePicker.getValue() == null) {
                return false;
            }
        }
        return true;
    }
    //El archivo usado se limpia para reactualizarlo
    private void LimpiarArchivo(String nombre_archivo){
        File archivo = new File(nombre_archivo);
        try (FileWriter fileWriter = new FileWriter(archivo)) {
            // Abrimos el archivo en modo de escritura
            // Esto eliminará todo su contenido anterior
        } catch (IOException e) {
            System.err.println("Error al borrar el contenido del archivo: " + e.getMessage());
        }
    } 
    // Permite escribir en un archivo al fin de este, sin necesidad de borrarlo
    private void EscribirArchivowithOW(String nombre_archivo, String Alimento_add){
        File archivo = new File(nombre_archivo);
        try {
            FileWriter fw = new FileWriter(archivo,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(Alimento_add);
            bw.close();
            fw.close();
        } catch (IOException e) {
            // Manejo de excepciones en caso de errores
            e.printStackTrace();
        }
    }
    //Funcion que permite separar de un limitir y a partir del delimitador, extraer la informacion
    private static String CreateSubString(String originalString, char delimiter){
        String substring="";
        int index = originalString.indexOf(delimiter);
        if (index != -1) {
            substring = originalString.substring(index + 2);
        } else {
            //System.out.println("No se encontró el caracter ':' en la cadena.");
        }
        return substring;
    }
    //Permite leer el archivo y extraer un arreglo con todas las lineas que cumplan la condicion del finder.
    public static List<String> LeerArchivo(String nombre_archivo, String finder){
        File archivo = new File(nombre_archivo);
        List<String> lines = new ArrayList<>();
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.contains(finder)){
                    lines.add(CreateSubString(linea,':'));
                }
            }
            // Cerrar Recursos
            br.close();
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }
    
    //Funcion que retorna los valores inidiales de los elementos y actualiza las listas con la informacion actual
    public void Return_Values(){
        InputAdditionalTextbox.setText("");
        InputcarbohidratosTextbox.setText("0.0");
        InputcodeTextbox.setText(""); 
        InputgrasaTextbox.setText("0.0"); 
        InputnameTextbox.setText(""); 
        InputproteinasTextbox.setText("0.0");
        Inputdate.setValue(null);
        ModifyCarbohidratosTextbox.setText("0.0"); 
        ModifyadditionalTextbox.setText("");
        ModifycodeTextbox.setText(""); 
        ModifygrasaTextbox.setText("0.0");
        ModifynameTextbox.setText(""); 
        ModifyproteinasTextbox.setText("0.0");
        ModifydateTextbox.setValue(null);
        SearchcodeTextbox.setText("");
        SearchDate.setValue(null);
        Create_Lists();
        ModifySummaryList.getItems().clear();
        for (int i = 0; i < List_Alimentos.size(); i++) {
            //System.out.print(List_Codigos.get(i));
            //System.out.print(List_Nombres.get(i));
            DataEntry_Summary dato = new DataEntry_Summary(List_Codigos.get(i),List_Nombres.get(i));
            ModifySummaryList.getItems().add(dato);
        }
        ModifySummaryList.setCellFactory(param -> new TwoColumnListCell());
        
        SearchListDetailed.getItems().clear();
        for (int i = 0; i < List_Alimentos.size(); i++) {
            //System.out.print(List_Codigos.get(i));
            //System.out.print(List_Nombres.get(i));
            DataEntry_Detailed dato = new DataEntry_Detailed(String.format("Alimento: %s", List_Alimentos.get(i)),String.format("Codigo: %s", List_Codigos.get(i))
                    ,String.format("Nombre: %s", List_Nombres.get(i)),String.format("Proteinas c/100g: %s", List_Proteinas.get(i)),
                    String.format("Carbohidratos c/100g: %s", List_Carbohidratos.get(i)), String.format("Grasas c/100g: %s", List_Grasas.get(i)), 
                    String.format("Fecha: %s", List_Dates.get(i)), String.format("Informacion Adicional: %s", List_Additional.get(i)));
            SearchListDetailed.getItems().add(dato);
        }
        SearchListDetailed.setCellFactory(param -> new EightColumnListCell());
    }
    
    public void Create_Lists(){
        List_Alimentos=LeerArchivo("Alimentos.txt", "Alimento");
        List_Codigos=LeerArchivo("Alimentos.txt", "Codigo");
        List_Nombres=LeerArchivo("Alimentos.txt", "Nombre");
        List_Proteinas=LeerArchivo("Alimentos.txt", "Proteina");
        List_Carbohidratos=LeerArchivo("Alimentos.txt", "Carbohidratos");
        List_Grasas=LeerArchivo("Alimentos.txt", "Grasa");
        List_Dates=LeerArchivo("Alimentos.txt", "Fecha");
        List_Additional=LeerArchivo("Alimentos.txt", "Adicional");
    }
    //Inicializados
    @FXML
    public void initialize() {
        Return_Values();
        //Combobox, agregar las dos opciones y dejar por defecto AlimentoPorcoesado para iniciar el programa
        InputfoodCombobox.getItems().addAll("AlimentoProcesado", "AlimentoNatural");
        InputfoodCombobox.setValue("AlimentoProcesado");
        //Dependiendiendo si es uno o otro cambiar un label
        InputfoodCombobox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String opcionSeleccionada = InputfoodCombobox.getValue();
                if("AlimentoProcesado".equals(opcionSeleccionada)){
                    InputLabelAddaptable.setText("Lista de Ingredientes");
                } else if ("AlimentoNatural".equals(opcionSeleccionada)){
                    InputLabelAddaptable.setText("Tipo de alimento");
                }
                else{
                    InputLabelAddaptable.setText("N/A");
                }  
            }
        });
        //Elementos que se agregar a las listas de elementos, antes descritas
        textInputFields.add(InputcarbohidratosTextbox);
        textInputFields.add(InputgrasaTextbox);
        textInputFields.add(InputproteinasTextbox);
        
        textModifyFields.add(ModifyCarbohidratosTextbox);
        textModifyFields.add(ModifygrasaTextbox);
        textModifyFields.add(ModifyproteinasTextbox);
        
        Date_List.add(Inputdate);
        Date_List.add(ModifydateTextbox);
        Date_List.add(SearchDate);
        
        // Usamos un TextFormatter para validar la entrada del TextField para valores doble, solo para la tab de Insercion
        for (TextField textInputField : textInputFields) {
            textInputField.setTextFormatter(new TextFormatter<>(
                new DoubleStringConverter(),
                0.0, // Valor predeterminado en caso de entrada no válida
                change -> {
                    String newText = change.getControlNewText();
                    if (newText.matches("-?\\d*(\\.\\d*)?")) { // Patrón para permitir números double
                        return change;
                    }
                    return null; // Rechazar la entrada no válida
                }
        ));
        }
        // Usamos un TextFormatter para validar la entrada del TextField para valores doble, solo para la tab de Modificar/Eliminar
        for (TextField textInputField : textModifyFields) {
            textInputField.setTextFormatter(new TextFormatter<>(
                new DoubleStringConverter(),
                0.0, // Valor predeterminado en caso de entrada no válida
                change -> {
                    String newText = change.getControlNewText();
                    if (newText.matches("-?\\d*(\\.\\d*)?")) { // Patrón para permitir números double
                        return change;
                    }
                    return null; // Rechazar la entrada no válida
                }
        ));
        }
        // Usamos un TextFormatter para validar la entrada del TextField para valores doble, para todos los DatePicker
        for (DatePicker datePicker : Date_List){
            // Configurar el formato deseado para el DatePicker
            String dateFormat = "dd/MM/yyyy";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateFormat);
            
            // Configurar el StringConverter para el DatePicker
            datePicker.setConverter(new StringConverter<LocalDate>() {
                @Override
                public String toString(LocalDate localDate) {
                    if (localDate != null) {
                        return dateFormatter.format(localDate);
                    }
                    return "";
                }

                @Override
                public LocalDate fromString(String dateString) {
                    try {
                        return LocalDate.parse(dateString, dateFormatter);
                    } catch (Exception e) {
                        return null;
                    }
                }
            });
        }
    }
                
    //Funcion, que sucede al presion el boton agregar
    @FXML
    void AddFood(ActionEvent event) {
        //Booleanos que revisan el llenado de los compas
        boolean allFieldsFilled = checkAllFieldsFilled(InputAdditionalTextbox, InputcarbohidratosTextbox, InputcodeTextbox, InputgrasaTextbox, InputnameTextbox, InputproteinasTextbox);
        boolean allDatePickerFilled = checkAllDatePicker(Inputdate);
        //Genera las Listas de Buses de datos
        Create_Lists();
        if (allFieldsFilled & allDatePickerFilled) {
            //Revisa que no haya ningun codigo igual
            if(!List_Codigos.contains(InputcodeTextbox.getText())){
                //Estructura Primaria
                Alimento mi_alimento = null;
                if (InputfoodCombobox.getValue().equals("AlimentoProcesado")){
                    //Guardamos en Variable lo escrito
                    String code= InputcodeTextbox.getText();
                    String name = InputnameTextbox.getText();
                    double proteinas = Double.parseDouble(InputproteinasTextbox.getText());
                    double carbohidratos = Double.parseDouble(InputcarbohidratosTextbox.getText());
                    double grasas = Double.parseDouble(InputgrasaTextbox.getText());
                    LocalDate fecha = Inputdate.getValue();
                    ArrayList<String> Lista_Ingredientes = new ArrayList<>(Arrays.asList(InputAdditionalTextbox.getText().split(",")));
                    //La variable mi_alimento le damos la herencia AlimentoProcesado y le asignamos su constructor
                    mi_alimento= new AlimentoProcesado(code, name, proteinas, carbohidratos,grasas, fecha, Lista_Ingredientes);
                    //Enviamos todo al archivo
                    EscribirArchivowithOW("Alimentos.txt",mi_alimento.toString());
                } else if (InputfoodCombobox.getValue().equals("AlimentoNatural")){
                    //Guardamos  en Variables lo descrito en la interfaz
                    String code= InputcodeTextbox.getText();
                    String name = InputnameTextbox.getText();
                    double proteinas = Double.parseDouble(InputproteinasTextbox.getText());
                    double carbohidratos = Double.parseDouble(InputcarbohidratosTextbox.getText());
                    double grasas = Double.parseDouble(InputgrasaTextbox.getText());
                    LocalDate fecha = Inputdate.getValue();
                    String Tipo = InputAdditionalTextbox.getText();
                    //La variable mi_alimento, le damos herencia AlimentoNatural y le asignamos s constructor
                    mi_alimento= new AlimentoNatural(code, name, proteinas, carbohidratos,grasas, fecha, Tipo);
                    //Enviamos el archivo a n string
                    EscribirArchivowithOW("Alimentos.txt",mi_alimento.toString());
                }
            } else{
                showAlert("Advertencia", "Codigo ya Ingresado para otro producto", Alert.AlertType.WARNING);
            }
            //Devolvemos la UI por defecto
            Return_Values();
        } else {
            showAlert("Advertencia", "Datos no Ingresados Completos", Alert.AlertType.WARNING);
        }
    }
    //Para la seccion de modify/delete, tenemos una lista para seleccionar que modificar o borrar
    int index;
    @FXML
    public void onListViewClicked(MouseEvent event) {
        //Captura el objeto seleccionado
        DataEntry_Summary ElementoSeleccionado = ModifySummaryList.getSelectionModel().getSelectedItem();
        //Logica de impresion a la UI
        if (ElementoSeleccionado != null) {
            index=List_Codigos.indexOf(ElementoSeleccionado.getColumn1Value());
            ModifycodeTextbox.setText(List_Codigos.get(index));
            ModifynameTextbox.setText(List_Nombres.get(index));
            ModifygrasaTextbox.setText(List_Grasas.get(index));
            ModifyproteinasTextbox.setText(List_Proteinas.get(index));
            ModifyCarbohidratosTextbox.setText(List_Carbohidratos.get(index));
            ModifyadditionalTextbox.setText(List_Additional.get(index));
            ModifydateTextbox.setValue(LocalDate.parse(List_Dates.get(index),DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            
            
            //ModifycodeTextbox.setEditable(true); Se comenta, ya que no se debe editar el codigo
            ModifynameTextbox.setEditable(true);
            ModifygrasaTextbox.setEditable(true);
            ModifyproteinasTextbox.setEditable(true);
            ModifyCarbohidratosTextbox.setEditable(true);
            ModifydateTextbox.setEditable(true);
            ModifyadditionalTextbox.setEditable(true);
            
            
        } else {
            index=-1;
        }
    }
    
    
    @FXML
    void ModifyFood(ActionEvent event) {
        // Revisa, todos los campos esten llenos en ese Tab
        boolean allFieldsFilled = checkAllFieldsFilled(ModifyCarbohidratosTextbox, ModifyadditionalTextbox, ModifycodeTextbox, ModifygrasaTextbox, ModifynameTextbox, ModifyproteinasTextbox);
        boolean allDatePickerFilled = checkAllDatePicker(ModifydateTextbox);
        if (allFieldsFilled & allDatePickerFilled) {
            if(index!=-1){
                //Modifica en el index, la informacion
                List_Codigos.set(index,ModifycodeTextbox.getText());
                List_Nombres.set(index, ModifynameTextbox.getText());
                List_Grasas.set(index, ModifygrasaTextbox.getText());
                List_Proteinas.set(index, ModifyproteinasTextbox.getText());
                List_Carbohidratos.set(index, ModifyCarbohidratosTextbox.getText());
                List_Additional.set(index, ModifyadditionalTextbox.getText());
                LocalDate Value_Date = ModifydateTextbox.getValue();
                List_Dates.set(index,Value_Date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                // Retorna valores por defecto
                ModifyCarbohidratosTextbox.setText("0.0"); 
                ModifyadditionalTextbox.setText("");
                ModifycodeTextbox.setText(""); 
                ModifygrasaTextbox.setText("0.0");
                ModifynameTextbox.setText(""); 
                ModifyproteinasTextbox.setText("0.0");
                ModifySummaryList.getItems().clear();
                //Actualiza la lista
                for (int i = 0; i < List_Alimentos.size(); i++) {
                    DataEntry_Summary dato = new DataEntry_Summary(List_Codigos.get(i),List_Nombres.get(i));
                    ModifySummaryList.getItems().add(dato);
                }
                //Retorna a por defecto las secciones de UI
                ModifydateTextbox.setValue(null);
                ModifycodeTextbox.setEditable(false);
                ModifynameTextbox.setEditable(false);
                ModifygrasaTextbox.setEditable(false);
                ModifyproteinasTextbox.setEditable(false);
                ModifyCarbohidratosTextbox.setEditable(false);
                ModifydateTextbox.setEditable(false);
                ModifyadditionalTextbox.setEditable(false);
                //Borra el archivo
                LimpiarArchivo("Alimentos.txt");
                //Escribe de nuevo todo el archivo
                for(int i=0; i<List_Codigos.size(); i++){
                    EscribirArchivowithOW("Alimentos.txt",String.format("Alimento: %s%n", List_Alimentos.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Codigo: %s%n", List_Codigos.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Nombre: %s%n", List_Nombres.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Proteina c/100g: %s%n", List_Proteinas.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Carbohidratos c/100g: %s%n", List_Carbohidratos.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Grasa c/100g: %s%n", List_Grasas.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Fecha: %s%n", List_Dates.get(i)));
                    EscribirArchivowithOW("Alimentos.txt",String.format("Adicional: %s%n", List_Additional.get(i)));
                }
            }
            //Retorna todos los campos a su valor original
            Return_Values();
        } else {
            //Mensaje de error si un campo no posee informacion
            showAlert("Advertencia", "Datos no Ingresados Completos", Alert.AlertType.WARNING);
        }
    }

    @FXML
    void RemoveFood(ActionEvent event) {
        //Revisa, que todos los campos, hayan sido completo, luego de seleccionar del ListView
        boolean allFieldsFilled = checkAllFieldsFilled(ModifyCarbohidratosTextbox, ModifyadditionalTextbox, ModifycodeTextbox, ModifygrasaTextbox, ModifynameTextbox, ModifyproteinasTextbox);
        boolean allDatePickerFilled = checkAllDatePicker(ModifydateTextbox);
        //Script que borra
        if (allFieldsFilled & allDatePickerFilled) {
            //Envia lo que borra al archivo Alimentos Eliminados
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Alimento: %s%n", List_Alimentos.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Codigo: %s%n", List_Codigos.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Nombre: %s%n", List_Nombres.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Proteina c/100g: %s%n", List_Proteinas.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Carbohidratos c/100g: %s%n", List_Carbohidratos.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Grasa c/100g: %s%n", List_Grasas.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Fecha: %s%n", List_Dates.get(index)));
            EscribirArchivowithOW("AlimentosEliminados.txt",String.format("Adicional: %s%n", List_Additional.get(index)));
            //Retirar de todas las listas el elemento a eliminar
            List_Alimentos.remove(index);
            List_Codigos.remove(index);
            List_Nombres.remove(index);
            List_Grasas.remove(index);
            List_Proteinas.remove(index);
            List_Carbohidratos.remove(index);
            List_Additional.remove(index);
            List_Dates.remove(index);
            //Actualizacion del List View
            ModifySummaryList.getItems().clear();
            for (int i = 0; i < List_Alimentos.size(); i++) {
                DataEntry_Summary dato = new DataEntry_Summary(List_Codigos.get(i),List_Nombres.get(i));
                ModifySummaryList.getItems().add(dato);
            }
            //Retorno de las celdas a UI por defecto
            ModifyCarbohidratosTextbox.setText("0.0"); 
            ModifyadditionalTextbox.setText("");
            ModifycodeTextbox.setText(""); 
            ModifygrasaTextbox.setText("0.0");
            ModifynameTextbox.setText(""); 
            ModifyproteinasTextbox.setText("0.0");
            ModifydateTextbox.setValue(null);
            ModifycodeTextbox.setEditable(false);
            ModifynameTextbox.setEditable(false);
            ModifygrasaTextbox.setEditable(false);
            ModifyproteinasTextbox.setEditable(false);
            ModifyCarbohidratosTextbox.setEditable(false);
            ModifydateTextbox.setEditable(false);
            ModifyadditionalTextbox.setEditable(false);
            //Se borra todo lo del archivo
            LimpiarArchivo("Alimentos.txt");
            //Se Rescribe toda la informacion al Archivo
            for(int i=0; i<List_Codigos.size(); i++){
                EscribirArchivowithOW("Alimentos.txt",String.format("Alimento: %s%n", List_Alimentos.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Codigo: %s%n", List_Codigos.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Nombre: %s%n", List_Nombres.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Proteina c/100g: %s%n", List_Proteinas.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Carbohidratos c/100g: %s%n", List_Carbohidratos.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Grasa c/100g: %s%n", List_Grasas.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Fecha: %s%n", List_Dates.get(i)));
                EscribirArchivowithOW("Alimentos.txt",String.format("Adicional: %s%n", List_Additional.get(i)));
            }
            //Retorna la UI por defecto
            Return_Values();
        } else {
            // Si algun valor fue borrado o no remplazado, da error
            showAlert("Advertencia", "Datos no Ingresados Completos", Alert.AlertType.WARNING);
        }
    }

    @FXML
    void SearchCodeFood(ActionEvent event) {
        //Chequea que textbox acorde, tenga informacion
        boolean allFieldsFilled = checkAllFieldsFilled(SearchcodeTextbox);
        //Busqueda del codigo
        if (allFieldsFilled) {
            //Lmpieza de la informacion
            SearchListDetailed.getItems().clear();
            //Muestra unicamente la informacion que cumpla
            for (int i = 0; i < List_Alimentos.size(); i++) {
                if (SearchcodeTextbox.getText().equals(List_Codigos.get(i))){
                    DataEntry_Detailed dato = new DataEntry_Detailed(String.format("Alimento: %s", List_Alimentos.get(i)),String.format("Codigo: %s", List_Codigos.get(i))
                        ,String.format("Nombre: %s", List_Nombres.get(i)),String.format("Proteinas c/100g: %s", List_Proteinas.get(i)),
                        String.format("Carbohidratos c/100g: %s", List_Carbohidratos.get(i)), String.format("Grasas c/100g: %s", List_Grasas.get(i)), 
                        String.format("Fecha: %s", List_Dates.get(i)), String.format("Informacion Adicional: %s", List_Additional.get(i)));
                    SearchListDetailed.getItems().add(dato);
                }
            }
        } else {
            //Muestra error en caso de no haberse llenado el TextBox
            showAlert("Advertencia", "Datos no Ingresados Completos", Alert.AlertType.WARNING);
        }
    }

    @FXML
    void SearchDateFood(ActionEvent event) {
        //Revisa que el Date Picker, tenga datos
        boolean allDatePickerFilled = checkAllDatePicker(SearchDate);
        //Funcion que busca todas los elementos que coincida la fecha
        if (allDatePickerFilled) {
            SearchListDetailed.getItems().clear();
            for (int i = 0; i < List_Alimentos.size(); i++) {
                if (SearchDate.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).equals(List_Dates.get(i))){
                    DataEntry_Detailed dato = new DataEntry_Detailed(String.format("Alimento: %s", List_Alimentos.get(i)),String.format("Codigo: %s", List_Codigos.get(i))
                        ,String.format("Nombre: %s", List_Nombres.get(i)),String.format("Proteinas c/100g: %s", List_Proteinas.get(i)),
                        String.format("Carbohidratos c/100g: %s", List_Carbohidratos.get(i)), String.format("Grasas c/100g: %s", List_Grasas.get(i)), 
                        String.format("Fecha: %s", List_Dates.get(i)), String.format("Informacion Adicional: %s", List_Additional.get(i)));
                    SearchListDetailed.getItems().add(dato);
                }
            }
        } else {
            //Muestra error si el DatePcker esta vacio.
            showAlert("Advertencia", "Datos no Ingresados Completos", Alert.AlertType.WARNING);
        }
    }
    
    //Funcion del boton de Ingresar al Welcome.
    @FXML
    void cambiarTab(ActionEvent event) {
        TP.getSelectionModel().select(AddTab);
    }
}

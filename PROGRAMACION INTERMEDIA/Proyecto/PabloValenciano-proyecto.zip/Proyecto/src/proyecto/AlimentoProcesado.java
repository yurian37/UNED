/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author pvale
 */
// Clase heredada de Alimento conocida como Alimento Procesado
public class AlimentoProcesado extends Alimento {
    //Variable de tipo arreglo agregada
    public ArrayList<String> Lista_Ingredientes;
    
    //Constructor de Alimento Procesado
    public AlimentoProcesado(String codigo, String nameFood,
            double proteina, double carbohidratos, 
            double grasas, LocalDate fechaCreacion, 
            ArrayList<String> Lista_Ingredientes){
        super(codigo,nameFood,proteina,carbohidratos, grasas, fechaCreacion);
        this.Lista_Ingredientes = Lista_Ingredientes;
    }
    
    //Convertir el arreglo a un string con comas separados
    public String ArraytoString(ArrayList<String> Lista_Strings){
        String Salida = String.join(",", Lista_Strings);
        return Salida;
    }
    // Funcion que hace el string de la funcion Alimento
    @Override
    public String toString(){
        return String.format("Alimento: Procesado%n"
                + "Codigo: %s%n"
                + "Nombre: %s%n"
                + "Proteina c/100g: %.2f%n"
                + "Carbohidratos c/100g: %.2f%n"
                + "Grasa c/100g: %.2f%n"
                + "Fecha: %s%n"
                + "Adicional: %s%n"
                ,super.codigo,super.nameFood,
                super.proteina,super.carbohidratos,super.grasas,
                super.fechaCreacion.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                ArraytoString(Lista_Ingredientes));
    }
}

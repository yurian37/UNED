/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author pvale
 */

//Clase creada para dar la informacion en la tabla con mas detalle
public class DataEntry_Detailed {
    private final StringProperty column1Value = new SimpleStringProperty();
    private final StringProperty column2Value = new SimpleStringProperty();
    private final StringProperty column3Value = new SimpleStringProperty();
    private final StringProperty column4Value = new SimpleStringProperty();
    private final StringProperty column5Value = new SimpleStringProperty();
    private final StringProperty column6Value = new SimpleStringProperty();
    private final StringProperty column7Value = new SimpleStringProperty();
    private final StringProperty column8Value = new SimpleStringProperty();
    
    //Constructor de la clase
    public DataEntry_Detailed(String column1Value, String column2Value, 
            String column3Value, String column4Value, String column5Value, 
            String column6Value, String column7Value, String column8Value) {
        setColumn1Value(column1Value);
        setColumn2Value(column2Value);
        setColumn3Value(column3Value);
        setColumn4Value(column4Value);
        setColumn5Value(column5Value);
        setColumn6Value(column6Value);
        setColumn7Value(column7Value);
        setColumn8Value(column8Value);
    }
    
    //Funcion que retorna el valor de cada elemento
    public String getColumn1Value() {
        return column1Value.get();
    }
    
    //Funcion que permite setear cada valor
    public void setColumn1Value(String value) {
        column1Value.set(value);
    }

    //Funcion que retorna la estructura de cada valor
    public StringProperty column1ValueProperty() {
        return column1Value;
    }

    public String getColumn2Value() {
        return column2Value.get();
    }

    public void setColumn2Value(String value) {
        column2Value.set(value);
    }

    public StringProperty column2ValueProperty() {
        return column2Value;
    }
    
    public String getColumn3Value() {
        return column3Value.get();
    }

    public void setColumn3Value(String value) {
        column3Value.set(value);
    }

    public StringProperty column3ValueProperty() {
        return column3Value;
    }
    
    public String getColumn4Value() {
        return column4Value.get();
    }

    public void setColumn4Value(String value) {
        column4Value.set(value);
    }

    public StringProperty column4ValueProperty() {
        return column4Value;
    }
    
    public String getColumn5Value() {
        return column5Value.get();
    }

    public void setColumn5Value(String value) {
        column5Value.set(value);
    }

    public StringProperty column5ValueProperty() {
        return column5Value;
    }
    
    public String getColumn6Value() {
        return column6Value.get();
    }

    public void setColumn6Value(String value) {
        column6Value.set(value);
    }

    public StringProperty column6ValueProperty() {
        return column6Value;
    }
    
    public String getColumn7Value() {
        return column7Value.get();
    }

    public void setColumn7Value(String value) {
        column7Value.set(value);
    }

    public StringProperty column7ValueProperty() {
        return column7Value;
    }
    
    public String getColumn8Value() {
        return column8Value.get();
    }

    public void setColumn8Value(String value) {
        column8Value.set(value);
    }

    public StringProperty column8ValueProperty() {
        return column8Value;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea1_biblioteca_multa;

/**
 *
 * @author pvale
 */
public class MultaUniversidad extends Multa{
    private String College;
    private String Carrer;
    private boolean Scholarship = false;
    
    //Calculo de Multa, en caso de tener una beca
    @Override
    public double CalcularMulta(){
        super.fine_mount= super.CalcularMulta()*0.75;
        return super.fine_mount;
    }
    //Metodo que pide el nombre de la Universidad con un maximo de 30 Caracteres
    public void set_College(){
        System.out.println("Digite el nombre de la universidad como un maximo de 30 caracteres:");
        //System.out.println("Ingrese una cadena de texto de maximo 30 caracteres:");
        College = entrada.nextLine();
        if (College.length() > 0 && College.length() <=30){
            System.out.println("Nombre con extension adecuada\n");
        }
        else {
            System.out.println("Nombre de la universidad con extension inadecuada digite otro para continuar\n");
            set_College();
        }
    }
    //Metodo que pide el nombre de la carrera con una extension maxima de 20 caracteres
    public void set_Carrer(){
        System.out.println("Digite el nombre de la carrera como un maximo de 20 caracteres:");
        //System.out.println("Ingrese una cadena de texto de maximo 20 caracteres:");
        Carrer = entrada.nextLine();
        if (Carrer.length() > 0 && Carrer.length() <=20){
            System.out.println("Nombre con extension adecuada\n");
        }
        else {
            System.out.println("Nombre de la carrera con extension inadecuada digite otro para continuar\n");
            set_Carrer();
        }
    }
    //Metodo que pregunta al usuario si tiene beca o no, se aplica la tarifa de una vez
    public void set_Scholarship(){
        System.out.print("Digite 'Si' o 'No' si el estudiante tiene Beca: ");
        String input = entrada.nextLine();
        if (input.equalsIgnoreCase("Si")) {
            Scholarship = true;
            CalcularMulta();
        } else if (input.equalsIgnoreCase("No")) {
            Scholarship = false;
            super.CalcularMulta();
        } else {
            System.out.println("Respuesta inválida. Intente nuevamente.");
            set_Scholarship();
        }
    }
    
    public String get_College(){ 
        return College;
    }
    
    public String get_Carrer(){ 
        return Carrer;
    }
    
    public boolean get_Scholarship(){
        return Scholarship;
    }
    
    //Metodo que imprime los valores de la Multa, agrega a los originales la informacion de la Universidad
    @Override
    public String toString(){
        return String.format("%s"
                + "Informacion de la Universidad" 
                + "%n%s: %s %s: %n%s %s: %b"
                + "%n------------- %n", super.toString(), "Universidad: ", College, "Carrera: ", Carrer, "Beca: ", Scholarship);
    }
    
}

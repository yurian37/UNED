/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea1_biblioteca_multa;

/**
 *
 * @author pvale
 */
public class MultaEscuela extends Multa{
    private String Tutor;
    private String Teacher;
    
    //Calculo de la multa para 
    @Override
    public double CalcularMulta(){
        super.fine_mount= super.CalcularMulta()*1.15;
        return super.fine_mount;
    }
    //Pregunta el nombre del encargado entre 10 y 35 Caracteres
    public void set_Tutor(){
        System.out.println("Digite el nombre de la persona encargada entre 10 y 35 caracteres:");
        //System.out.println("Ingrese una cadena de texto de maximo 30 caracteres:");
        Tutor = entrada.nextLine();
        if (Tutor.length() >= 10 && Tutor.length() <=35){
            System.out.println("Nombre con extension adecuada\n");
        }
        else {
            System.out.println("Nombre de la persona encargada con extension inadecuada digite otro para continuar\n");
            set_Tutor();
        }
    }
    //Pregunta el profesor que dio el libro entre 10 a 15 Caracteres
    public void set_Teacher(){
        System.out.println("Digite el nombre del profesor que autorizo entre 10 y 35 caracteres:");
        //System.out.println("Ingrese una cadena de texto de maximo 30 caracteres:");
        Teacher = entrada.nextLine();
        if (Teacher.length() >= 10 && Teacher.length() <=35){
            System.out.println("Nombre con extension adecuada\n");
        }
        else {
            System.out.println("Nombre del profesor con extension inadecuada digite otro para continuar\n");
            set_Teacher();
        }
    }
    
    public String get_Tutor(){
        return Tutor;
    }
    
    public String get_Teacher(){
        return Teacher;
    }
    //Metodo que imprime los valores de la Multa, agrega a los originales la informacion de la Escuela
    @Override
    public String toString(){
        return String.format("%s"
                + "Informacion de la Escuela" 
                + "%n%s: %s %n%s: %s"
                + "%n------------- %n", super.toString(), "Persona Encargada: ", Tutor, "Profesor: ", Teacher);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.resourceallocator;

/**
 *
 * @author pvale
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ResourceAllocator extends JFrame {
    private JTextField[][] demandMatrix, allocationMatrix;
    private JTextField[] resourceVector;
    private JTextField[] availableResources;
    private JTextArea resultMatrix;
    private JTextArea logArea;
    private JButton calculateButton, stepButton;
    private int[][] demand, allocation, need;
    private int[] resources, available;
    private boolean[] finished;
    private int currentStep = 0;

    public ResourceAllocator() {
        setTitle("Banker's Algorithm Simulation");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 1));
        inputPanel.add(createMatrixPanel("Resource Vector", 1, 3, resourceVector = new JTextField[3]));
        inputPanel.add(createMatrixPanel("Demand Matrix", 3, 3, demandMatrix = new JTextField[3][3]));
        inputPanel.add(createMatrixPanel("Allocation Matrix", 3, 3, allocationMatrix = new JTextField[3][3]));
        inputPanel.add(createMatrixPanel("Available Resources", 1, 3, availableResources = new JTextField[3]));

        for (JTextField field : availableResources) {
            field.setEditable(false);
        }

        add(inputPanel, BorderLayout.NORTH);

        resultMatrix = new JTextArea(5, 20);
        resultMatrix.setEditable(false);
        add(new JScrollPane(resultMatrix), BorderLayout.CENTER);

        logArea = new JTextArea(10, 20);
        logArea.setEditable(false);
        add(new JScrollPane(logArea), BorderLayout.SOUTH);

        JPanel buttonPanel = new JPanel();
        calculateButton = new JButton("Calculate Available Resources");
        stepButton = new JButton("Step Algorithm");
        stepButton.setEnabled(false);
        buttonPanel.add(calculateButton);
        buttonPanel.add(stepButton);
        add(buttonPanel, BorderLayout.EAST);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateInputs()) {
                    calculateAvailableResources();
                    updateResultMatrix();
                    stepButton.setEnabled(true);
                    currentStep = 0;
                    logArea.setText("");
                }
            }
        });

        stepButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stepAlgorithm();
            }
        });
    }

    private JPanel createMatrixPanel(String title, int rows, int cols, JTextField[][] fields) {
        JPanel panel = new JPanel(new GridLayout(rows + 1, cols + 1));
        panel.setBorder(BorderFactory.createTitledBorder(title));
        panel.add(new JLabel());
        for (int j = 0; j < cols; j++) {
            panel.add(new JLabel("R" + (j + 1), SwingConstants.CENTER));
        }
        for (int i = 0; i < rows; i++) {
            panel.add(new JLabel("P" + (i + 1), SwingConstants.CENTER));
            for (int j = 0; j < cols; j++) {
                fields[i][j] = new JTextField(3);
                panel.add(fields[i][j]);
            }
        }
        return panel;
    }

    private JPanel createMatrixPanel(String title, int rows, int cols, JTextField[] fields) {
        JPanel panel = new JPanel(new GridLayout(rows + 1, cols + 1));
        panel.setBorder(BorderFactory.createTitledBorder(title));
        panel.add(new JLabel());
        for (int j = 0; j < cols; j++) {
            panel.add(new JLabel("R" + (j + 1), SwingConstants.CENTER));
        }
        for (int i = 0; i < rows; i++) {
            panel.add(new JLabel("", SwingConstants.CENTER));
            for (int j = 0; j < cols; j++) {
                fields[j] = new JTextField(3);
                panel.add(fields[j]);
            }
        }
        return panel;
    }

    private boolean validateInputs() {
        try {
            resources = new int[3];
            demand = new int[3][3];
            allocation = new int[3][3];

            for (int i = 0; i < 3; i++) {
                resources[i] = Integer.parseInt(resourceVector[i].getText());
                if (resources[i] < 0) throw new NumberFormatException();
            }

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    demand[i][j] = Integer.parseInt(demandMatrix[i][j].getText());
                    allocation[i][j] = Integer.parseInt(allocationMatrix[i][j].getText());
                    if (demand[i][j] < 0 || allocation[i][j] < 0) throw new NumberFormatException();
                    if (demand[i][j] > resources[j]) {
                        JOptionPane.showMessageDialog(this, "Demand cannot exceed available resources.");
                        return false;
                    }
                    if (allocation[i][j] > demand[i][j]) {
                        JOptionPane.showMessageDialog(this, "Allocation cannot exceed demand.");
                        return false;
                    }
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "All inputs must be non-negative integers.");
            return false;
        }
        return true;
    }

    private void calculateAvailableResources() {
        available = new int[3];
        for (int j = 0; j < 3; j++) {
            available[j] = resources[j];
            for (int i = 0; i < 3; i++) {
                available[j] -= allocation[i][j];
            }
            availableResources[j].setText(String.valueOf(available[j]));
        }
    }

    private void updateResultMatrix() {
        need = new int[3][3];
        StringBuilder sb = new StringBuilder("Need Matrix:\n");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                need[i][j] = demand[i][j] - allocation[i][j];
                sb.append(need[i][j]).append("\t");
            }
            sb.append("\n");
        }
        resultMatrix.setText(sb.toString());
    }

    private void stepAlgorithm() {
        if (currentStep == 0) {
            finished = new boolean[3];
            logArea.append("Starting Banker's Algorithm\n");
        }

        boolean found = false;
        for (int i = 0; i < 3; i++) {
            if (!finished[i] && canAllocate(i)) {
                for (int j = 0; j < 3; j++) {
                    available[j] += allocation[i][j];
                }
                finished[i] = true;
                found = true;
                logArea.append("Step " + (currentStep + 1) + ": Allocated resources to Process " + (i + 1) + "\n");
                updateAvailableResources();
                break;
            }
        }

        if (!found) {
            if (isFinished()) {
                logArea.append("System is in a safe state. All processes can finish.\n");
                stepButton.setEnabled(false);
            } else {
                logArea.append("System is in an unsafe state. Deadlock may occur.\n");
                stepButton.setEnabled(false);
            }
        }

        currentStep++;
    }

    private boolean canAllocate(int process) {
        for (int j = 0; j < 3; j++) {
            if (need[process][j] > available[j]) {
                return false;
            }
        }
        return true;
    }

    private boolean isFinished() {
        for (boolean f : finished) {
            if (!f) return false;
        }
        return true;
    }

    private void updateAvailableResources() {
        for (int j = 0; j < 3; j++) {
            availableResources[j].setText(String.valueOf(available[j]));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ResourceAllocator().setVisible(true);
            }
        });
    }
}
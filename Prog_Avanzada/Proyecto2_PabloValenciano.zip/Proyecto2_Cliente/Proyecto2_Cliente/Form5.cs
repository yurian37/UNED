﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	public partial class Form5 : Form
	{
		private List<Pedido> lista_pedidos;
		public Form5()
		{
			InitializeComponent();
			this.Load += Form5_Load;
			ConfigurarColumnasDataGridView();
			dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
		}

		private void Form5_Load(object sender, EventArgs e)
		{
			label2.Text = TcpManejoConexion.NombreUsuario(Form2.iDseleecionado);

			lista_pedidos = TcpManejoConexion.PedidosporCliente(Form2.iDseleecionado);
			List<Articulo> lista_articulos = TcpManejoConexion.lista_articulos("Articulos");

			LlenarPedidos(lista_pedidos);


		}

		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Id Pedido");
			dataGridView1.Columns.Add("Columna2", "Fecha Pedido");
			dataGridView1.Columns.Add("Columna2", "Monto Total");
			dataGridView2.Columns.Add("Columna1", "ID articulo");
			dataGridView2.Columns.Add("Columna2", "Nombre");
			dataGridView2.Columns.Add("Columna3", "Precio");

			foreach (DataGridViewColumn columna in dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
			foreach (DataGridViewColumn columna in dataGridView2.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void DataGridView1_SelectionChanged(object sender, EventArgs e)
		{
			if (dataGridView1.SelectedRows.Count > 0)
			{
				string id_asignacion_s = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
				int id_asignacion;
				if (int.TryParse(id_asignacion_s, out id_asignacion))
				{
					LlenarDatosArticulos(lista_pedidos, id_asignacion);
				}
			}
		}

		private void LlenarPedidos(List<Pedido> pedidos)
		{
			dataGridView1.Rows.Clear();
			foreach (Pedido pedido in pedidos)
			{
				int suma = 0;
				List<Articulo> articulosPedido = new List<Articulo>();
				foreach (var item in pedido.Articulos)
				{

					suma = suma + item.Precio;
				}
				dataGridView1.Rows.Add(pedido.IdPedido, pedido.FechaPedido, suma);
			}
		}

		private void LlenarDatosArticulos(List<Pedido> pedidos, int id_asignacion)
		{
			dataGridView2.Rows.Clear();
			Pedido pedido = pedidos.FirstOrDefault(e => e.IdPedido == id_asignacion);
			List<Articulo> articulosnoNull = new List<Articulo>();
			foreach (var valorA in pedido.Articulos)
			{
				articulosnoNull.Add(valorA);
			}
			foreach (Articulo articulo in articulosnoNull)
			{
				dataGridView2.Rows.Add(articulo.IdArticulo, articulo.Nombre, articulo.Precio);
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form3 form3 = new Form3();
			form3.Show();
			this.Close();
		}
	}
}

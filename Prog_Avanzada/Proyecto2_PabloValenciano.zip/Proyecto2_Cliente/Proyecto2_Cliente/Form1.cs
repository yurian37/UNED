﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	
	public partial class Form1 : Form
	{
		bool clienteConectado = false;
		public static string Identificador;
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (!(textBox1.Text.Equals(string.Empty)))
			{
				if (TcpManejoConexion.Conectar(textBox1.Text))
				{
					clienteConectado = true;
					Identificador = textBox1.Text;
					MessageBox.Show("Conexion Establecida con Exito");
					this.Hide();
					Form2 form2 = new Form2();
					form2.Show();
					this.Close();
				}
				else
				{
					MessageBox.Show("Verifique que el servidor esté escuchando clientes...", "No es posible conectarse", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
			}
			else
			{
				MessageBox.Show("Debe ingresar el identificador del cliente", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}

		private void Form1_FormClosed(object sender, EventArgs e)
		{
			Application.Exit();
		}
	}
}

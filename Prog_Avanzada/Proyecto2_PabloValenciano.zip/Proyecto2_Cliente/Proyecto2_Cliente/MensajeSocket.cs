﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	public class MensajeSocket<T>
	{
		public string Metodo { get; set; }
		public T Entidad { get; set; }
	}
}

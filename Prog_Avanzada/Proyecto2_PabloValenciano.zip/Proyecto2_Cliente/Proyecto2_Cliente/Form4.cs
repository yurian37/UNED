﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	
	public partial class Form4 : Form
	{
		private List<string> lista_pedidos_ids;
		private List<int> lista_hoteles;
		private List<Articulo> lista_articulos;
		private List<ArticuloHotel> lista_articuloshotel;
		private int Costo = 0;
		public Form4()
		{
			InitializeComponent();
			this.Load += Form4_Load1;
			comboBox1.DropDownClosed += ComboBox1_DropDownClosed;
			ConfigurarDataGridView1();
			ConfigurarDataGridView2();
		}

		private void Form4_Load1(object sender, EventArgs e)
		{
			

			label2.Text = TcpManejoConexion.NombreUsuario(Form2.iDseleecionado);
			lista_articulos = TcpManejoConexion.lista_articulos("Articulos");
			lista_articuloshotel = TcpManejoConexion.lista_articuloshotel("ArticulosHotel");

			lista_hoteles = TcpManejoConexion.lista_ids_hoteles("Hoteles");
			comboBox1.Items.Clear();
			foreach (int id in lista_hoteles)
			{
				comboBox1.Items.Add(id);
			}
			lista_pedidos_ids = TcpManejoConexion.lista_pedidos("Pedidos");
		}
		private void Form4_FormClosed(object sender, EventArgs e)
		{
			TcpManejoConexion.Desconectar(Form1.Identificador);
			Application.Exit();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form3 form3 = new Form3();
			form3.Show();
			this.Close();
		}

		private void ComboBox1_DropDownClosed(object sender, EventArgs e)
		{
			LlenarDatos();
			dataGridView2.Rows.Clear();	
		}

		private void ConfigurarDataGridView1()
		{
			dataGridView1.ReadOnly = false;
			dataGridView1.AutoGenerateColumns = false;
			dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			dataGridView1.CellContentClick += DataGridView1_CellContentClick;

			DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
			checkBoxColumn.HeaderText = "Seleccionar";
			checkBoxColumn.Name = "Seleccionado";
			dataGridView1.Columns.Add(checkBoxColumn);

			dataGridView1.Columns.Add("IdArticulo", "ID articulo");
			dataGridView1.Columns.Add("Nombre", "Nombre");
			dataGridView1.Columns.Add("Precio", "Precio");
		}

		private void LlenarDatos()
		{
			List<Articulo> lista_total_articulos = new List<Articulo>();
			List<Articulo> lista_total_articulos_sin_repetir = new List<Articulo>();
			foreach (ArticuloHotel articuloHotel in lista_articuloshotel)
			{
				if (articuloHotel.Hotel.Id == int.Parse(comboBox1.SelectedItem.ToString()))
				{
					foreach (Articulo articulo in articuloHotel.Articulos)
					{
						lista_total_articulos.Add(articulo);
					}
				}
			}
			lista_total_articulos_sin_repetir = lista_total_articulos.Distinct().ToList();

			dataGridView1.Rows.Clear();
			foreach (Articulo articulo1 in lista_total_articulos_sin_repetir)
			{
				DataGridViewRow fila = new DataGridViewRow();
				fila.CreateCells(dataGridView1);

				fila.Cells[0].Value = false;
				fila.Cells[1].Value = articulo1.IdArticulo.ToString();
				fila.Cells[2].Value = articulo1.Nombre;
				fila.Cells[3].Value = articulo1.Precio.ToString();

				dataGridView1.Rows.Add(fila);
			}
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				DataGridViewCheckBoxCell checkBoxCell = row.Cells["Seleccionado"] as DataGridViewCheckBoxCell;
				checkBoxCell.Value = false;
			}
		}

		private void ConfigurarDataGridView2()
		{
			dataGridView2.Columns.Add("IdArticulo", "ID articulo");
			dataGridView2.Columns.Add("Nombre", "Nombre");
			dataGridView2.Columns.Add("Precio", "Precio");
			dataGridView2.ReadOnly = true;
		}
		private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == dataGridView1.Columns["Seleccionado"].Index && e.RowIndex != -1)
			{
				Articulo articulo_seleccionado = lista_articulos[e.RowIndex];

				DataGridViewRow filanueva = new DataGridViewRow();
				filanueva.CreateCells(dataGridView2);
				filanueva.Cells[0].Value = articulo_seleccionado.IdArticulo;
				filanueva.Cells[1].Value = articulo_seleccionado.Nombre;
				filanueva.Cells[2].Value = articulo_seleccionado.Precio;
				Costo= Costo + articulo_seleccionado.Precio;
				dataGridView2.Rows.Add(filanueva);
			}
			label7.Text = Costo.ToString();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			int id_pedido;
			if (!(textBox1.Text == "")) {
				if (int.TryParse(textBox1.Text, out id_pedido))
				{
					if (!lista_pedidos_ids.Contains(textBox1.Text))
					{
						if (!(comboBox1.SelectedItem.ToString() == ""))
						{
							if (dataGridView2.Rows.Count > 0)
							{
								DateTime dateTime = dateTimePicker1.Value;
								Cliente cliente = TcpManejoConexion.ObtenerCliente(Form2.iDseleecionado);
								List<string> lista_ids = new List<string>();
								foreach (DataGridViewRow fila in dataGridView2.Rows)
								{
									object valorCelda = fila.Cells[0].Value;
									lista_ids.Add(valorCelda?.ToString());
								}
								List<Articulo> articulosEncontrados = lista_articulos
									.Where(articulo => lista_ids.Contains(articulo.IdArticulo.ToString())).ToList();
								Articulo[] arregloArticulos = articulosEncontrados.Take(10).ToArray();
								Pedido pedido = new Pedido(id_pedido, dateTime, cliente, arregloArticulos);
								bool PedidoAprobado = TcpManejoConexion.AgregarPedido(pedido);
								if (PedidoAprobado)
								{
									MessageBox.Show("Pedido Entregado");
									lista_pedidos_ids.Add(Convert.ToString(id_pedido));
								}
								else
								{
									MessageBox.Show("Pedido Rechazado");
								}
							}
							else
							{
								MessageBox.Show("No se han agregado Articulos");
							}
						}
						else
						{
							MessageBox.Show("No se ha seleccionado un Hotel");
						}
					}
					else
					{
						MessageBox.Show("Ese Id de Pedido ya pertenece a otro miembre");
					}
				}
				else
				{
					MessageBox.Show("El pedido debe ser un numero entero");
				}
			}
			else
			{
				MessageBox.Show("No se ha indicado el ID del Pedido");
			}
		}
	}
}

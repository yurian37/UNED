﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	public partial class Form2 : Form
	{
		private List<string> lista_ids;
		public static string iDseleecionado;
		public Form2()
		{
			InitializeComponent();
			this.Load += Form2_Load1;
		}

		private void Form2_Load1(object sender, EventArgs e)
		{

			lista_ids = TcpManejoConexion.lista_ids("Clientes");
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string id = textBox1.Text;
			if (!string.IsNullOrEmpty(id) && lista_ids.Contains(id))
			{
				iDseleecionado = id;
				this.Hide();
				Form3 form3 = new Form3();
				form3.Show();
				this.Close();
			}
			else
			{
				MessageBox.Show("Usuario no Valido");
			}
		}
		private void Form2_FormClosed(object sender, EventArgs e)
		{
			TcpManejoConexion.Desconectar(Form1.Identificador);
			Application.Exit();
		}
	}
}

﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.CompilerServices;
using System.Linq.Expressions;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto2_Cliente
{
	public class TcpManejoConexion
	{
		private static IPAddress ipServidor;
		private static TcpClient cliente;
		private static IPEndPoint serverEndPoint;
		private static StreamWriter clienteStreamWriter;
		private static StreamReader clienteStreamReader;

		private static bool EnviarRespuesta(string mensaje)
		{
			try
			{
				clienteStreamWriter.WriteLine(mensaje);
				clienteStreamWriter.Flush();

				return true;
			}
			catch (Exception)
			{
				return false;
			}

		}
		public static bool Conectar(string pIdentificadorCliente)
		{
			try
			{
				ipServidor = IPAddress.Parse("127.0.0.1");
				cliente = new TcpClient();
				serverEndPoint = new IPEndPoint(ipServidor, 13200);
				cliente.Connect(serverEndPoint);
				MensajeSocket<string> mensajeConectar = new MensajeSocket<string> { Metodo = "Conectar", Entidad = pIdentificadorCliente };

				clienteStreamReader = new StreamReader(cliente.GetStream());
				clienteStreamWriter = new StreamWriter(cliente.GetStream());
				//EnviarRespuesta(JsonConvert.SerializeObject(mensajeConectar));
			}
			catch { return false; }

			return true;
		}

		public static void Desconectar(string pIdentificadorCliente)
		{
			//MensajeSocket<string> mensajeDesconectar = new MensajeSocket<string> { Metodo = "Desconectar", Entidad = pIdentificadorCliente };
			//EnviarRespuesta(JsonConvert.SerializeObject(mensajeDesconectar));

			//Se cierra la conexión del cliente
			cliente.Close();
		}

		public static List<string> lista_pedidos(string id_pedido)
		{
			MensajeSocket<string> mensajeObtenerIdsPedidos = new MensajeSocket<string> { Metodo = "ListaPedidos", Entidad = id_pedido };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeObtenerIdsPedidos));

			var mensaje = clienteStreamReader.ReadLine();
			var listaIDs = JsonConvert.DeserializeObject<List<int>>(mensaje);

			List<string> listaID_s = new List<string>();
			foreach (var id in listaIDs)
			{
				listaID_s.Add(Convert.ToString(id));
			}

			return listaID_s;
		}
		public static List<string> lista_ids(string id_cliente)
		{
			MensajeSocket<string> mensajeObtenerIdsClientes = new MensajeSocket<string> { Metodo = "ListaIDs", Entidad = id_cliente };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeObtenerIdsClientes));

			var mensaje = clienteStreamReader.ReadLine();
			var listaIDs = JsonConvert.DeserializeObject<List<string>>(mensaje);

			return listaIDs;
		}

		public static List<int> lista_ids_hoteles(string id_hotel)
		{
			MensajeSocket<string> mensajeObtenerIdsClientes = new MensajeSocket<string> { Metodo = "ListaIDhotel", Entidad = id_hotel };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeObtenerIdsClientes));

			var mensaje = clienteStreamReader.ReadLine();
			var listaIDs = JsonConvert.DeserializeObject<List<int>>(mensaje);

			return listaIDs;
		}

		public static List<Articulo> lista_articulos(string id_articulo)
		{
			MensajeSocket<string> mensajeObtenerIdsClientes = new MensajeSocket<string> { Metodo = "ListaArticulos", Entidad = id_articulo };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeObtenerIdsClientes));

			var mensaje = clienteStreamReader.ReadLine();
			var listaArticulos = JsonConvert.DeserializeObject<List<Articulo>>(mensaje);

			return listaArticulos;
		}

		public static List<ArticuloHotel> lista_articuloshotel(string id_articulohotel)
		{
			MensajeSocket<string> mensajeObtenerIdsClientes = new MensajeSocket<string> { Metodo = "ListaArticuloHotel", Entidad = id_articulohotel };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeObtenerIdsClientes));

			var mensaje = clienteStreamReader.ReadLine();
			var listaArticulosHotel = JsonConvert.DeserializeObject<List<ArticuloHotel>>(mensaje);

			return listaArticulosHotel;
		}

		public static string NombreUsuario(string id_cliente)
		{
			MensajeSocket<string> mensajeNombreCliente = new MensajeSocket<string> { Metodo = "ClienteID", Entidad = id_cliente };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeNombreCliente));

			var mensaje = clienteStreamReader.ReadLine();
			var ClienteID = JsonConvert.DeserializeObject<string>(mensaje);

			return ClienteID;
		}

		public static Cliente ObtenerCliente(string id_cliente)
		{
			MensajeSocket<string> mensajeBuscarCliente = new MensajeSocket<string> { Metodo = "BuscarCliente", Entidad = id_cliente };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeBuscarCliente));

			var mensaje = clienteStreamReader.ReadLine();
			var ClienteID = JsonConvert.DeserializeObject<Cliente>(mensaje);

			return ClienteID;
		}

		public static List<Pedido> PedidosporCliente(string id_cliente)
		{
			MensajeSocket<string> mensajeBuscarPedidoCliente = new MensajeSocket<string> { Metodo = "BuscarPedidoCliente", Entidad = id_cliente };
			EnviarRespuesta(JsonConvert.SerializeObject(mensajeBuscarPedidoCliente));

			var mensaje = clienteStreamReader.ReadLine();
			var lista_pedidos = JsonConvert.DeserializeObject<List<Pedido>>(mensaje);

			return lista_pedidos;
		}

		public static bool AgregarPedido(Pedido nuevoPedido)
		{
			MensajeSocket<Pedido> mensajePedido = new MensajeSocket<Pedido> { Metodo = "AgregarPedido", Entidad = nuevoPedido };
			return EnviarRespuesta(JsonConvert.SerializeObject(mensajePedido));
		}

		private void EnviarRespuesta(string respuesta, ref StreamWriter servidorStreamWriter)
		{
			try
			{
				servidorStreamWriter.WriteLine(respuesta);
				servidorStreamWriter.Flush();
			}
			catch
			{
				// Manejo de excepciones al enviar la respuesta
				MessageBox.Show("No fue posible enviar los datos del stream writer");
			}
		}
		
		
	}
}

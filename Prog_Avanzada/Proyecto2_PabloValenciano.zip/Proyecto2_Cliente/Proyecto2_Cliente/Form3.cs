﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */
namespace Proyecto2_Cliente
{
	public partial class Form3 : Form
	{
		public Form3()
		{
			InitializeComponent();
			this.Load += Form3_Load1;
		}

		private void Form3_Load1(object sender, EventArgs e)
		{
			label3.Text = TcpManejoConexion.NombreUsuario(Form2.iDseleecionado);
		}

		private void Form3_FormClosed(object sender, EventArgs e)
		{
			TcpManejoConexion.Desconectar(Form1.Identificador);
			Application.Exit();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			TcpManejoConexion.Desconectar(Form1.Identificador);
			this.Hide();
			Form1 form1 = new Form1();
			form1.Show();
			this.Close();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form4 form4 = new Form4();
			form4.Show();
			this.Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form5 form5 = new Form5();
			form5.Show();
			this.Close();
		}
	}

}

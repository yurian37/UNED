﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect01: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 25/02/2024
 * 
 * */

namespace Entidades
{
	public class ArticuloHotel
	{
		public int IdAsignacion { get; set; }
		public DateTime Fecha { get; set; }
		public Hotel Hotel { get; set; }
		public Articulo[] Articulos { get; set; }

		public ArticuloHotel(int idAsignacion, DateTime fecha, Hotel hotel, Articulo[] articulos)
		{
			IdAsignacion = idAsignacion;
			Fecha = fecha;
			Hotel = hotel;
			Articulos = articulos;
		}
	}
}

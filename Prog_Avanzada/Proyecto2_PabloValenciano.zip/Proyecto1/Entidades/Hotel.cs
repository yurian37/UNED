﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect01: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 25/02/2024
 * 
 * */

namespace Entidades
{
	public class Hotel
	{
		public int Id { get; set; }
		public string NombreHotel { get; set; }
		public string Direccion { get; set; } 
		public bool Estado { get; set; }
		public string Telefono { get; set; }

		public Hotel(int id, string nombreHotel, string direccion, bool estado, string telefono)
		{
			Id = id;
			NombreHotel = nombreHotel;
			Direccion = direccion;
			Estado = estado;
			Telefono = telefono;
		}
	}
}

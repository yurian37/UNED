﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect01: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 25/02/2024
 * 
 * */

namespace Entidades
{
	public class Cliente
	{
		public string Identificacion { get; set; }
		public string Nombre { get; set; }
		public string Apellido1 { get; set; }
		public string Apellido2 { get; set; }
		public DateTime FechaNacimiento { get; set; }
		public char Genero { get; set; }

		public Cliente(string identificacion, string nombre, string apellido1, string apellido2, DateTime fechaNacimiento, char genero)
		{
			Identificacion = identificacion;
			Nombre = nombre;
			Apellido1 = apellido1;
			Apellido2 = apellido2;
			FechaNacimiento = fechaNacimiento;
			Genero = genero;
		}
	}
}

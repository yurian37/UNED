﻿using Logica;
using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class RegistrarCategoríaArtículos : Form
	{
		ConectarDataBase conectarData = new ConectarDataBase();
		RegistrarCategoriaArticulo registrarCategoriaArticulo = new RegistrarCategoriaArticulo();
		public RegistrarCategoríaArtículos()
		{
			InitializeComponent();
			radioButton1.Checked = registrarCategoriaArticulo.RevisarLleno(InicializarListas.lista_categoriaArticulos);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			bool bool_estado = true;
			int id_numero = -1;

			string id = textBox1.Text;
			string descripcion = textBox2.Text;
			
			string estado = comboBox1.SelectedItem.ToString();
			if (estado == "Activo")
			{
				 bool_estado = true;
			}
			else
			{
				bool_estado = false;
			}
			if (int.TryParse(id, out id_numero))
			{
				CategoriaArticulo categoriaArticulo_agregar = new CategoriaArticulo(id_numero,descripcion,bool_estado);
				bool bool_registro = registrarCategoriaArticulo.AgregarCategoriaArticulo(InicializarListas.lista_categoriaArticulos, categoriaArticulo_agregar);
				if (bool_registro)
				{
					conectarData.AgregarCategoriaArticulo(categoriaArticulo_agregar);
					MessageBox.Show("Registro Correcto");
				}
				else
				{
					MessageBox.Show("Registro no Posible");
				}
			}
			else
			{
				MessageBox.Show("Registro no Posible");
			}
		}
	}
}

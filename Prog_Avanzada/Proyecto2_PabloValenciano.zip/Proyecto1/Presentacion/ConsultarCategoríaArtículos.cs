﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class ConsultarCategoríaArtículos : Form
	{
		public ConsultarCategoríaArtículos()
		{
			InitializeComponent();
			ConfigurarColumnasDataGridView();
			LlenarDatos();
		}

		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Id categoria");
			dataGridView1.Columns.Add("Columna2", "Descripcion");
			dataGridView1.Columns.Add("Columna3", "Estado");

			foreach (DataGridViewColumn columna in dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void LlenarDatos()
		{
			List<CategoriaArticulo> categoriaArticulonoNull = new List<CategoriaArticulo>();
			foreach (var valor in InicializarListas.lista_categoriaArticulos)
			{
				if (valor != null)
				{
					categoriaArticulonoNull.Add(valor);
				}
			}
			string estado = "";
			foreach (CategoriaArticulo categoriaArticulo in categoriaArticulonoNull)
			{
				if (categoriaArticulo.Estado == true) { estado = "Activo"; }
				else { estado = "Inactivo"; }
				dataGridView1.Rows.Add(categoriaArticulo.IdCategoria.ToString(), categoriaArticulo.Descripcion, estado);
			}
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Logica;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	internal static class Program
	{
		/// <summary>
		/// Punto de entrada principal para la aplicación.
		/// </summary>
		[STAThread]
		static void Main()
		{
			InicializarListas.InicializaListas();
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			Menu_Principal menu_Principal = new Menu_Principal();
			menu_Principal.FormClosed += MenuPrincipal_Closed;
			menu_Principal.ShowDialog();
			Application.Run();
		}

		private static void MenuPrincipal_Closed(object sender, EventArgs e)
		{
			//((Form1)sender).FormClosed -= Form1_Closed;

			if (Application.OpenForms.Count == 0)
			{
				Application.ExitThread();
			}
			else
			{
				Application.OpenForms[0].FormClosed += MenuPrincipal_Closed;
			}

		}
	}
}

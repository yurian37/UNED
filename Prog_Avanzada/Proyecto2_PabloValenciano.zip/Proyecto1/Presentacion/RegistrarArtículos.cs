﻿using Logica;
using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect01: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 25/02/2024
 * 
 * */

namespace Proyecto1
{
	public partial class RegistrarArtículos : Form
	{
		ConectarDataBase conectarData = new ConectarDataBase();
		RegistrarArticulo registrarArticulo = new RegistrarArticulo();
		public RegistrarArtículos()
		{
			InitializeComponent();
			radioButton1.Checked = registrarArticulo.RevisarLleno(InicializarListas.lista_articulos);
			this.Load += RegistrarArtículos_Load;
		}

		private void RegistrarArtículos_Load(object sender, EventArgs e)
		{
			string[] datos = InicializarListas.lista_categoriaArticulos
				.Where(objeto => objeto != null)
				.Select(objeto => objeto.IdCategoria.ToString())
				.ToArray();
			comboBox1.Items.Clear();
			comboBox1.Items.AddRange(datos);

			if (comboBox1.Items.Count > 0)
			{
				comboBox1.SelectedIndex = 0;
			}
		}
		private void button1_Click(object sender, EventArgs e)
		{
			int idArticulo_int = -1;
			int idCategoria_int = -1;
			int Precio_int = -1;

			string idArticulo = textBox1.Text;
			string nombre = textBox2.Text;
			string Precio = textBox3.Text;
			string idCategoria = comboBox1.Text;

			if (int.TryParse(idArticulo, out idArticulo_int) && int.TryParse(idCategoria, out idCategoria_int)
				&& int.TryParse(Precio, out Precio_int))
			{
				CategoriaArticulo categoriaArticulo = InicializarListas.lista_categoriaArticulos.FirstOrDefault(obj => obj != null && obj.IdCategoria == idCategoria_int);
				
				Articulo articulo_agregar = new Articulo(idArticulo_int, nombre, Precio_int, categoriaArticulo);
				bool bool_registro = registrarArticulo.AgregarArticulo(InicializarListas.lista_articulos, articulo_agregar);
				if (bool_registro)
				{
					conectarData.AgregarArticulo(articulo_agregar);
					MessageBox.Show("Registro Correcto");
				}
				else
				{
					MessageBox.Show("Registro no Posible");
				}
			}
			else
			{
				MessageBox.Show("Registro no Posible");
			}
		}
	}
}

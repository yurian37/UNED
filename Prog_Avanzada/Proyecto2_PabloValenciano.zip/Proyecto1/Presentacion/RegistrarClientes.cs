﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class RegistrarClientes : Form
	{
		ConectarDataBase conectarData = new ConectarDataBase();
		RegistrarCliente registrarCliente = new RegistrarCliente();
		public RegistrarClientes()
		{
			InitializeComponent();
			radioButton1.Checked = registrarCliente.RevisarLleno(InicializarListas.lista_clientes);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string identificador = textBox1.Text;
			string nombre = textBox2.Text;
			string apellido1 = textBox3.Text;
			string apellido2 = textBox4.Text;
			DateTime fechaNacimiento = dateTimePicker1.Value;
			char genero = comboBox1.SelectedItem.ToString().ToCharArray()[0];
			Cliente cliente_agregar = new Cliente(identificador, nombre, apellido1, apellido2, fechaNacimiento, genero);
			bool bool_registro = registrarCliente.AgregarCliente(InicializarListas.lista_clientes,cliente_agregar);
            if (bool_registro)
			{
				conectarData.AgregarCliente(cliente_agregar);
				MessageBox.Show("Registro Correcto");
			}
			else
			{
				MessageBox.Show("Registro no Posible");
			}
        }
	}
}

﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class RegistrarArtículoporHotel : Form
	{
		RegistrarArticuloHotel registrarArticuloHotel = new RegistrarArticuloHotel();
		ConectarDataBase conectarData = new ConectarDataBase();
		private ComboBox comboBox1;
		public RegistrarArtículoporHotel()
		{
			if (AgregaralComboBox(InicializarListas.lista_hoteles))
			{
				InitializeComponent();
				ConfigurarDataGridView1();
				ConfigurarDataGridView2();
			}
		}

		private bool AgregaralComboBox(Hotel[] hotels)
		{
			List<string> hoteles_activos_id = new List<string>();
			foreach (Hotel hotel in hotels)
			{
				if (hotel != null)
				{
					if (hotel.Estado == true)
					{
						hoteles_activos_id.Add(hotel.Id.ToString());
					}
				}
			}
			if (hoteles_activos_id.Count != 0)
			{
				comboBox1 = new ComboBox();
				comboBox1.DataSource = hoteles_activos_id;
				comboBox1.Font = new Font("Arial", 28);
				comboBox1.Location = new Point(12, 60);
				comboBox1.Size = new Size(100, 50);
				Controls.Add(comboBox1);
				comboBox1.DropDownClosed += ComboBox1_DropDownClosed;
				return true;
			}
			else
			{
				MessageBox.Show("No hay hoteles para asignar, no es posible acceder a esta seccion");
				return false;
			}
		}



		private void ComboBox1_DropDownClosed(object sender, EventArgs e)
		{
			int id_int;
			string id = comboBox1.SelectedItem.ToString();
			id_int = Convert.ToInt32(id);
			Hotel hotel = InicializarListas.lista_hoteles.FirstOrDefault(p => p.Id == id_int);
			textBox2.Text = hotel.NombreHotel;
			textBox3.Text = hotel.Direccion;
			dataGridView2.Rows.Clear();
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				DataGridViewCheckBoxCell checkBoxCell = row.Cells["Seleccionado"] as DataGridViewCheckBoxCell;
				checkBoxCell.Value = false;
			}
		}

		private void ConfigurarDataGridView1()
		{
			dataGridView1.ReadOnly = false;
			dataGridView1.AutoGenerateColumns = false;
			dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			dataGridView1.CellContentClick += DataGridView1_CellContentClick;

			DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
			checkBoxColumn.HeaderText = "Seleccionar";
			checkBoxColumn.Name = "Seleccionado";
			dataGridView1.Columns.Add(checkBoxColumn);

			dataGridView1.Columns.Add("IdArticulo", "ID articulo");
			dataGridView1.Columns.Add("Nombre", "Nombre");
			dataGridView1.Columns.Add("Precio", "Precio");

			List<Articulo> articulosnoNull = new List<Articulo>();
			foreach (var valor in InicializarListas.lista_articulos)
			{
				if (valor != null)
				{
					articulosnoNull.Add(valor);
				}
			}
			for (int i = 0; i < articulosnoNull.Count; i++)
			{
				DataGridViewRow fila = new DataGridViewRow();
				fila.CreateCells(dataGridView1);

				fila.Cells[0].Value = false;
				fila.Cells[1].Value = articulosnoNull[i].IdArticulo.ToString();
				fila.Cells[2].Value = articulosnoNull[i].Nombre;
				fila.Cells[3].Value = articulosnoNull[i].Precio.ToString();

				dataGridView1.Rows.Add(fila);
			}
		}

		private void ConfigurarDataGridView2()
		{
			dataGridView2.Columns.Add("IdArticulo", "ID articulo");
			dataGridView2.Columns.Add("Nombre", "Nombre");
			dataGridView2.Columns.Add("Precio", "Precio");
			dataGridView2.ReadOnly = true;
		}
		private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == dataGridView1.Columns["Seleccionado"].Index && e.RowIndex != -1)
			{
				Articulo articulo_seleccionado = InicializarListas.lista_articulos[e.RowIndex];

				DataGridViewRow filanueva = new DataGridViewRow();
				filanueva.CreateCells(dataGridView2);
				filanueva.Cells[0].Value = articulo_seleccionado.IdArticulo;
				filanueva.Cells[1].Value = articulo_seleccionado.Nombre;
				filanueva.Cells[2].Value = articulo_seleccionado.Precio;

				dataGridView2.Rows.Add(filanueva);
				//dataGridView1.Rows.RemoveAt(e.RowIndex);
			}

			if (dataGridView2.Rows.Count == 10)
			{
				dataGridView1.ReadOnly = true;
			}
			else
			{
				dataGridView1.ReadOnly = false;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			int id_numero = -1;

			string id = textBox1.Text;
			if (int.TryParse(id, out id_numero))
			{
				if (dataGridView2.Rows.Count > 0)
				{
					List <string> lista_ids = new List<string>();
					foreach(DataGridViewRow fila in dataGridView2.Rows)
					{
						object valorCelda = fila.Cells[0].Value;
						lista_ids.Add(valorCelda?.ToString());
					}
					List <Articulo> articulosnoNulos = new List<Articulo>();
					foreach(Articulo articulo1 in InicializarListas.lista_articulos)
					{
						if (articulo1 != null)
						{
							articulosnoNulos.Add(articulo1);
						}
					}
					List <Articulo> articulosEncontrados = articulosnoNulos
						.Where(articulo => lista_ids.Contains(articulo.IdArticulo.ToString())).ToList();
					Articulo[] arregloArticulos = articulosEncontrados.Take(10).ToArray();
					string hotelbuscar = comboBox1.SelectedItem.ToString();
					Hotel hotel_registrar = InicializarListas.lista_hoteles.FirstOrDefault(hotel => hotel.Id.ToString() == hotelbuscar);
					DateTime dateTime = dateTimePicker1.Value;
					ArticuloHotel articuloHotel_agregar = new ArticuloHotel(id_numero, dateTime, hotel_registrar, arregloArticulos);
					bool bool_registro = registrarArticuloHotel.AgregarArticuloHotel(InicializarListas.lista_articulohotel, articuloHotel_agregar);
					if (bool_registro)
					{
						conectarData.AgregarArticuloHotel(articuloHotel_agregar);
						MessageBox.Show("Registro Correcto");
					}
					else
					{
						MessageBox.Show("Registro no Posible");
					}
				}
				else
				{
					MessageBox.Show("Registro no Posible");
				}
			}
			else
			{
				MessageBox.Show("Registro no Posible");
			}
		}
	}
}

﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	
	public partial class ConsultarArtículosporHotel : Form
	{
		public ComboBox comboBox1;
		public ConsultarArtículosporHotel()
		{
			if (AgregaralComboBox(InicializarListas.lista_hoteles))
			{
				InitializeComponent();
				ConfigurarColumnasDataGridView();
				dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
			}
		}

		private bool AgregaralComboBox(Hotel[] hotels)
		{
			List<string> hoteles_activos_id = new List<string>();
			foreach (Hotel hotel in hotels)
			{
				if (hotel != null)
				{
					if (hotel.Estado == true)
					{
						hoteles_activos_id.Add(hotel.Id.ToString());
					}
				}
			}
			if (hoteles_activos_id.Count != 0)
			{
				comboBox1 = new ComboBox();
				comboBox1.DataSource = hoteles_activos_id;
				comboBox1.Font = new Font("Arial", 24);
				comboBox1.Location = new Point(298, 24);
				comboBox1.Size = new Size(220, 54);
				Controls.Add(comboBox1);
				comboBox1.DropDownClosed += ComboBox1_DropDownClosed;
				return true;
			}
			else
			{
				MessageBox.Show("No hay hoteles para asignar, no es posible acceder a esta seccion");
				return false;
			}
		}

		private void ComboBox1_DropDownClosed(object sender, EventArgs e)
		{
			int id_int;
			string id = comboBox1.SelectedItem.ToString();
			id_int = Convert.ToInt32(id);
			Hotel hotel = InicializarListas.lista_hoteles.FirstOrDefault(p => p.Id == id_int);
			dataGridView1.Rows.Clear();
			LlenarDatos(hotel.Id);
		}

		private void DataGridView1_SelectionChanged(object sender, EventArgs e)
		{
			if (dataGridView1.SelectedRows.Count > 0)
			{
				string id_asignacion_s = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
				int id_asignacion;
				if (int.TryParse(id_asignacion_s, out id_asignacion))
				{
					LlenarDatosArticulos(id_asignacion);
				}
			}
		}

		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Id asignacion");
			dataGridView1.Columns.Add("Columna2", "Fecha asignacion");
			dataGridView1.Columns.Add("Columna3", "ID Hotel");
			dataGridView1.Columns.Add("Columna4", "Nombre Hotel");
			dataGridView1.Columns.Add("Columna5", "Direccion Hotel");
			/*dataGridView1.Columns.Add("Columna6", "ID articulo");
			dataGridView1.Columns.Add("Columna7", "Nombre");
			dataGridView1.Columns.Add("Columna8", "Precio");*/
			dataGridView2.Columns.Add("Columna1", "ID articulo");
			dataGridView2.Columns.Add("Columna2", "Nombre");
			dataGridView2.Columns.Add("Columna3", "Precio");

			foreach (DataGridViewColumn columna in dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
			foreach (DataGridViewColumn columna in dataGridView2.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void LlenarDatos(int id_hotel)
		{
			dataGridView1.Rows.Clear();
			List<ArticuloHotel> articuloshotelnoNull = new List<ArticuloHotel>();
			foreach (var valor in InicializarListas.lista_articulohotel)
			{
				if (valor != null && valor.Hotel.Id == id_hotel)
				{
					articuloshotelnoNull.Add(valor);
				}
			}
			foreach (ArticuloHotel articuloHotel in articuloshotelnoNull)
			{
				dataGridView1.Rows.Add(articuloHotel.IdAsignacion, articuloHotel.Fecha, articuloHotel.Hotel.Id, 
					articuloHotel.Hotel.NombreHotel, articuloHotel.Hotel.Direccion/*, false, false, false*/);
				/*List<Articulo> articulosnoNull = new List<Articulo>();
				foreach (var valorA in articuloHotel.Articulos)
				{
					if (valorA != null)
					{
						articulosnoNull.Add(valorA);
					}
				}
				foreach (Articulo articulo in articulosnoNull)
				{
					dataGridView1.Rows.Add(false, false, false, false, false, articulo.IdArticulo, articulo.Nombre, articulo.Precio);
				}
				*/
			}
		}
		private void LlenarDatosArticulos(int id_asignacion)
		{
			dataGridView2.Rows.Clear();
			ArticuloHotel articuloHotel = InicializarListas.lista_articulohotel.FirstOrDefault(e => e.IdAsignacion == id_asignacion);
			List<Articulo> articulosnoNull = new List<Articulo>();
			foreach (var valorA in articuloHotel.Articulos)
			{
				if (valorA != null)
				{
					articulosnoNull.Add(valorA);
				}
			}
			foreach (Articulo articulo in articulosnoNull)
			{
				dataGridView2.Rows.Add(articulo.IdArticulo, articulo.Nombre, articulo.Precio);
			}
		}
	}
}

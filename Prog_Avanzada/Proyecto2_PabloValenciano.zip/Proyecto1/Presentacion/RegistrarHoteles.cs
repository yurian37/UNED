﻿using Logica;
using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class RegistrarHoteles : Form
	{
		ConectarDataBase conectarData = new ConectarDataBase();
		RegistrarHotel registrarHotel = new RegistrarHotel();
		public RegistrarHoteles()
		{
			InitializeComponent();
			radioButton1.Checked = registrarHotel.RevisarLleno(InicializarListas.lista_hoteles);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			bool bool_estado = true;
			int id_numero = -1;
			
			string id = textBox1.Text;
			string nombrehotel = textBox2.Text;
			string direccion = textBox3.Text;
			string estado = comboBox1.SelectedItem.ToString();
			string telefono = textBox4.Text;

			if (estado == "Activo")
			{
				bool_estado = true;
			}
			else
			{
				bool_estado = false;
			}
			if (int.TryParse(id, out id_numero))
			{
				Hotel hotel_agregar = new Hotel(id_numero, nombrehotel, direccion, bool_estado, telefono);
				bool bool_registro = registrarHotel.AgregarHotel(InicializarListas.lista_hoteles, hotel_agregar);
				if (bool_registro)
				{
					conectarData.AgregarHotel(hotel_agregar);
					MessageBox.Show("Registro Correcto");
				}
				else
				{
					MessageBox.Show("Registro no Posible");
				}
			}
			else
			{
				MessageBox.Show("Registro no Posible");
			}

		}
	}
}

﻿using Logica;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Entidades;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class Menu_Principal : Form
	{
		private readonly ServerTCP server = new ServerTCP(4);
		private FormController formController = new FormController();
		private ConectarDataBase conectarDB = new ConectarDataBase();
		public Menu_Principal()
		{
			
			InitializeComponent();
			ConectarDataBase conectarDataBase = new ConectarDataBase();
			conectarDataBase.ObtenerHoteles();
			conectarDataBase.ObtenerClientes();
			conectarDataBase.ObtenerCategoriaArticulos();
			conectarDataBase.ObtenerArticulos();
			conectarDataBase.ObtenerArticulosHotel();
			//server.Start();
			server.MensajeRecibido += ComunicacionTCP_MensajeRecibido;
		}



		private void ComunicacionTCP_MensajeRecibido(object sender, (string mensaje, StreamWriter streamWriter) e)
		{
			try
			{
				var mensajeRecibido = JsonConvert.DeserializeObject<MensajeSocket<object>>(e.mensaje);
				SeleccionarMetodo(mensajeRecibido.Metodo, mensajeRecibido.Entidad, ref e.streamWriter);
			}
			catch (JsonException)
			{
				MessageBox.Show("No fue posible convertir el objeto.");
			}
			catch (Exception ex)
			{
				MessageBox.Show("No fue posible guardar los datos correctamente.", ex.Message);
			}
		}

		private void ObtenerIDs(ref StreamWriter servidorStreamWriter)
		{
			try
			{
				List <string> listaIds = new List<string>();
				foreach (Cliente cliente in InicializarListas.lista_clientes)
				{
					if (cliente != null)
					{
						 listaIds.Add(cliente.Identificacion.ToString());
					}
				}
				EnviarRespuesta(JsonConvert.SerializeObject(listaIds), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerArticulos(ref StreamWriter servidorStreamWriter)
		{
			try
			{
				List<Articulo> listaArticulo = new List<Articulo>();
				foreach (Articulo articulo in InicializarListas.lista_articulos)
				{
					if (articulo != null)
					{
						listaArticulo.Add(articulo);
					}
				}
				EnviarRespuesta(JsonConvert.SerializeObject(listaArticulo), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerArticulosHotel(ref StreamWriter servidorStreamWriter)
		{
			try
			{
				List<ArticuloHotel> listaArticuloHotel = new List<ArticuloHotel>();
				foreach (ArticuloHotel articulohotel in InicializarListas.lista_articulohotel)
				{
					if (articulohotel != null)
					{
						listaArticuloHotel.Add(articulohotel);
					}
				}
				EnviarRespuesta(JsonConvert.SerializeObject(listaArticuloHotel), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerHotelesActivos(ref StreamWriter servidorStreamWriter)
		{
			try
			{
				List<int> listaIds = new List<int>();
				//int i = 0;
				foreach (Hotel hotel in InicializarListas.lista_hoteles)
				{
					if (hotel != null)
					{
						if (hotel.Estado == true)
						{
							listaIds.Add(hotel.Id);
						}
					}
				}
				EnviarRespuesta(JsonConvert.SerializeObject(listaIds), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerIDsPPedidos(ref StreamWriter servidorStreamWriter)
		{
			try
			{
				List<int> listaPedidos = new List<int>();
				//int i = 0;
				listaPedidos = conectarDB.ObtenerPedido();
				EnviarRespuesta(JsonConvert.SerializeObject(listaPedidos), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerPedidosCliente(ref StreamWriter servidorStreamWriter, string cliente)
		{
			try
			{
				List<Pedido> listaPedidos = new List<Pedido>();
				listaPedidos = conectarDB.ObtenerPedidoCliente();
				List<Pedido> listaPedidos_Cliente = new List<Pedido>();
				foreach (Pedido item in listaPedidos)
				{
					if (item.Cliente.Identificacion == cliente)
					{
						listaPedidos_Cliente.Add(item);
					}
				}
				EnviarRespuesta(JsonConvert.SerializeObject(listaPedidos_Cliente), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void ObtenerClienteId(ref StreamWriter servidorStreamWriter, string idCliente)
		{
			try
			{
				string nombreCompleto;
				Cliente cliente = InicializarListas.lista_clientes.FirstOrDefault(p => p.Identificacion.ToString() == idCliente);
				nombreCompleto = cliente.Nombre +" "+ cliente.Apellido1 +" "+ cliente.Apellido2;
				EnviarRespuesta(JsonConvert.SerializeObject(nombreCompleto), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		private void BuscarCliente(ref StreamWriter servidorStreamWriter, string idCliente)
		{
			try
			{
				Cliente cliente = InicializarListas.lista_clientes.FirstOrDefault(p => p.Identificacion.ToString() == idCliente);
				EnviarRespuesta(JsonConvert.SerializeObject(cliente), ref servidorStreamWriter);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Se presentó un error: {0}", ex.Message);
			}
		}

		public void SeleccionarMetodo(string pMetodo, object entidad, ref StreamWriter servidorStreamWriter)
		{
			switch (pMetodo)
			{
				case "ListaIDs":
					ObtenerIDs(ref servidorStreamWriter);
					break;
				case "ClienteID":
					var idCliente = JsonConvert.DeserializeObject<string>(JsonConvert.SerializeObject(entidad));
					ObtenerClienteId(ref servidorStreamWriter, idCliente);
					break;
				case "ListaIDhotel":
					ObtenerHotelesActivos(ref servidorStreamWriter);
					break;
				case "ListaArticulos":
					ObtenerArticulos(ref servidorStreamWriter);
					break;
				case "ListaArticuloHotel":
					ObtenerArticulosHotel(ref servidorStreamWriter);
					break;
				case "ListaPedidos":
					ObtenerIDsPPedidos(ref servidorStreamWriter);
					break;
				case "BuscarCliente":
					var idCliente2 = JsonConvert.DeserializeObject<string>(JsonConvert.SerializeObject(entidad));
					BuscarCliente(ref servidorStreamWriter, idCliente2);
					break;
				case "AgregarPedido":
					var nuevoPedido = JsonConvert.DeserializeObject<Pedido>(JsonConvert.SerializeObject(entidad));
					conectarDB.AgregarPedido(nuevoPedido);
					break;
				case "BuscarPedidoCliente":
					var idCliente3 = JsonConvert.DeserializeObject<string>(JsonConvert.SerializeObject(entidad));
					ObtenerPedidosCliente(ref servidorStreamWriter, idCliente3);
					break;
				/*case "Desconectar":
					Desconectar((string)entidad);
					break;*/
				default:
					// Manejar el método desconocido si es necesario
					break;
			}
		}
		private void button1_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedItem != null)
			{
				String Opcion1 = comboBox1.SelectedItem.ToString();
				if (Opcion1 == "Registrar Hotel")
				{
					RegistrarHoteles registrarHotel = new RegistrarHoteles();
					formController.ShowForm(registrarHotel);
				}
				else if (Opcion1 == "Consultar Hotel")
				{
					ConsultarHoteles consultarHotel = new ConsultarHoteles();
					formController.ShowForm(consultarHotel);
				}
			}

		}

		private void button3_Click(object sender, EventArgs e)
		{
			if (comboBox3.SelectedItem != null)
			{
				String Opcion3 = comboBox3.SelectedItem.ToString();
				if (Opcion3 == "Registrar Categoría Artículo")
				{
					RegistrarCategoríaArtículos registrarCategoríaArtículo = new RegistrarCategoríaArtículos();
					formController.ShowForm(registrarCategoríaArtículo);
				}
				else if (Opcion3 == "Registrar Artículos")
				{
					RegistrarArtículos registrarArtículos = new RegistrarArtículos();
					formController.ShowForm(registrarArtículos);
				}
				else if (Opcion3 == "Registrar Artículo por Hotel")
				{
					RegistrarArtículoporHotel registrarArtículoporHotel = new RegistrarArtículoporHotel();
					formController.ShowForm(registrarArtículoporHotel);
				}
				else if (Opcion3 == "Consultar Categoría Artículo")
				{
					ConsultarCategoríaArtículos consultarCategoríaArtículo = new ConsultarCategoríaArtículos();
					formController.ShowForm(consultarCategoríaArtículo);
				}
				else if (Opcion3 == "Consultar Artículo")
				{
					ConsultarArtículos consultarArtículo = new ConsultarArtículos();
					formController.ShowForm(consultarArtículo);
				}
				else if (Opcion3 == "Consultar Artículos por Hotel")
				{
					ConsultarArtículosporHotel consultarArtículosporHotel = new ConsultarArtículosporHotel();
					formController.ShowForm(consultarArtículosporHotel);
				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (comboBox2.SelectedItem != null)
			{
				String Opcion2 = comboBox2.SelectedItem.ToString();
				if (Opcion2 == "Registrar Clientes")
				{
					RegistrarClientes registrarClientes = new RegistrarClientes();
					formController.ShowForm(registrarClientes);
				}
				else if (Opcion2 == "Consultar Clientes")
				{
					ConsultarClientes consultarClientes = new ConsultarClientes();
					formController.ShowForm(consultarClientes);
				}
			}
		}

		private void EnviarRespuesta(string respuesta, ref StreamWriter servidorStreamWriter)
		{
			try
			{
				servidorStreamWriter.WriteLine(respuesta);
				servidorStreamWriter.Flush();
			}
			catch
			{
				// Manejo de excepciones al enviar la respuesta
				MessageBox.Show("No fue posible enviar los datos del stream writer");
			}
		}

		private void MenuPrincipal_Closed(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			server.Start();
			label4.Text = "Conectado";
		}

		private void button5_Click(object sender, EventArgs e)
		{
			server.Stop();
			label4.Text = "Desconectado";
		}
	}
}

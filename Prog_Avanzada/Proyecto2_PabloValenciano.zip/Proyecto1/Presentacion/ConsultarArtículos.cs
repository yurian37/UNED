﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class ConsultarArtículos : Form
	{
		public ConsultarArtículos()
		{
			InitializeComponent();
			ConfigurarColumnasDataGridView();
			LlenarDatos();
		}
		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Id articulo");
			dataGridView1.Columns.Add("Columna2", "Nombre");
			dataGridView1.Columns.Add("Columna3", "Precio");
			dataGridView1.Columns.Add("Columna3", "idCategoria");

			foreach (DataGridViewColumn columna in dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void LlenarDatos()
		{
			List<Articulo> articulonoNull = new List<Articulo>();
			foreach (var valor in InicializarListas.lista_articulos)
			{
				if (valor != null)
				{
					articulonoNull.Add(valor);
				}
			}
			foreach (Articulo articulo in articulonoNull)
			{
				dataGridView1.Rows.Add(articulo.IdArticulo.ToString(), articulo.Nombre, articulo.Precio.ToString(), articulo.IdCategoria.IdCategoria.ToString()); 
			}
		}
	}
}

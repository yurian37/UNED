﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Logica;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class ConsultarClientes : Form
	{
		public ConsultarClientes()
		{
			InitializeComponent();
			ConfigurarColumnasDataGridView();
			LlenarDatos();
		}
		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Identificacion");
			dataGridView1.Columns.Add("Columna2", "Nombre");
			dataGridView1.Columns.Add("Columna3", "Primer Apellido");
			dataGridView1.Columns.Add("Columna4", "Segundo Apellido");
			dataGridView1.Columns.Add("Columna5", "Fecha de Nacimiento");
			dataGridView1.Columns.Add("Columna6", "Genero");

			foreach (DataGridViewColumn columna in  dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void LlenarDatos()
		{
			List <Cliente> clientesnoNull = new List<Cliente> ();
			foreach (var valor in InicializarListas.lista_clientes)
			{
				if (valor != null)
				{
					clientesnoNull.Add (valor);
				}
			}
			foreach (Cliente cliente in clientesnoNull)
			{
				dataGridView1.Rows.Add(cliente.Identificacion, cliente.Nombre, cliente.Apellido1,
					cliente.Apellido2, cliente.FechaNacimiento.ToString(), cliente.Genero.ToString());
			}
		}
	}
}

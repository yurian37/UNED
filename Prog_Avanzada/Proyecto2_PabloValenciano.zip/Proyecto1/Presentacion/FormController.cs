﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public class FormController
	{
		private Form activeForm;

		public void ShowForm(Form newForm)
		{
			if (activeForm != null)
			{
				activeForm.Hide();
			}
			newForm.FormClosed += (s, args) => ShowPreviousForm();
			activeForm = newForm;
			newForm.Show();
		}

		private void ShowPreviousForm()
		{
			if (activeForm != null && !activeForm.IsDisposed) {
				activeForm.Dispose();
				activeForm=null;
			}
		}
	}
}

﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Proyecto1
{
	public partial class ConsultarHoteles : Form
	{
		public ConsultarHoteles()
		{
			InitializeComponent();
			ConfigurarColumnasDataGridView();
			LlenarDatos();
		}

		private void ConfigurarColumnasDataGridView()
		{
			dataGridView1.Columns.Add("Columna1", "Id de hotel");
			dataGridView1.Columns.Add("Columna2", "Nombre del Hotel");
			dataGridView1.Columns.Add("Columna3", "Direccion");
			dataGridView1.Columns.Add("Columna4", "Estado");
			dataGridView1.Columns.Add("Columna5", "Telefono");

			foreach (DataGridViewColumn columna in dataGridView1.Columns)
			{
				columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
		}

		private void LlenarDatos()
		{
			List<Hotel> hotelnoNull = new List<Hotel>();
			foreach (var valor in InicializarListas.lista_hoteles)
			{
				if (valor != null)
				{
					hotelnoNull.Add(valor);
				}
			}
			string estado = "";
			foreach (Hotel hotel in hotelnoNull)
			{
				if (hotel.Estado == true) { estado = "Activo"; }
				else { estado = "Inactivo"; }
				dataGridView1.Rows.Add(hotel.Id.ToString(), hotel.NombreHotel, hotel.Direccion, estado, hotel.Telefono);
			}
		}
	}
}

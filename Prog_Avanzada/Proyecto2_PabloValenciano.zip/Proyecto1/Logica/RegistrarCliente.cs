﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class RegistrarCliente
	{
		public bool AgregarCliente(Cliente[] lista_clientes, Cliente cliente_add)
		{
			if (!RevisarLleno(lista_clientes) && !RevisarIDRepetido(lista_clientes,cliente_add.Identificacion) && RevisarnoVacios(cliente_add))
			{
				for (int i = 0; i < lista_clientes.Length; i++)
				{
					if (lista_clientes[i] == null)
					{
						lista_clientes[i] = cliente_add;
						break;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}
		public bool RevisarLleno(Cliente[] lista_clientes)
		{
			foreach (Cliente elemento in lista_clientes)
			{
				if(elemento == null)
				{
					return false ;
				}
			}
			return true;
		}

		private bool RevisarIDRepetido(Cliente[] lista_clientes, string id)
		{
			foreach (Cliente elemento in lista_clientes)
				if (elemento != null)
				{
					{
						if (id == elemento.Identificacion)
						{
							return true;
						}
					}
				}
			return false;
		}

		private bool RevisarnoVacios(Cliente cliente)
		{
			if (cliente.Identificacion == "" || cliente.Nombre == "" || cliente.Apellido1=="" || cliente.Apellido2 == "")
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
}

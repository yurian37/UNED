﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using Entidades;
using System.IO;
using System.Security.Cryptography;

/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class ServerTCP
	{
		private TcpListener tcpListener;
		private bool servidorIniciado;
		private Semaphore semaphore;

		public event EventHandler<(string mensaje, StreamWriter streamWriter)> MensajeRecibido;

		public ServerTCP(int maxConnections)
		{
			var local = System.Net.IPAddress.Parse("127.0.0.1");
			tcpListener = new TcpListener(local, 13200);
			this.semaphore = new Semaphore(maxConnections,maxConnections);
		}

		public void Start()
		{
			servidorIniciado = true;
			tcpListener.Start();

			Thread serverThread = new Thread(new ThreadStart(StartListening));
			serverThread.IsBackground = true;
			serverThread.Start();
		}

		public void Stop()
		{
			servidorIniciado = false;
			tcpListener.Stop();
		}

		private void StartListening()
		{
			while (servidorIniciado)
			{
				try
				{
					TcpClient client = tcpListener.AcceptTcpClient();
					Thread thread = new Thread(HandleClient);
					thread.Start(client);
				}
				catch (Exception ex)
				{

				}
			}
		}

		private void HandleClient(object client) {
			semaphore.WaitOne();
			var tcpClient = (TcpClient)client;
			var reader = new StreamReader(tcpClient.GetStream());
			var writer = new StreamWriter(tcpClient.GetStream());

			while (servidorIniciado)
			{
				try
				{
					var mensaje = reader.ReadLine();
					//Utilizamos invoke para disparar el evento.
					MensajeRecibido?.Invoke(this, (mensaje, writer));
				}
				catch (IOException)
				{
					// IOException se lanza cuando se desconecta el cliente, no es necesario manejarlo
					break;
				}
			}
			tcpClient.Close();
			semaphore.Release();
		}
	}
}

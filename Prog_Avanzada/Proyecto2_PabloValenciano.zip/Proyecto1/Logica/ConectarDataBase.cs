﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades;
using System.Configuration;
using System.Runtime.InteropServices;
using System.IO;

/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class ConectarDataBase
	{
		private string cadenaConexion;
		RegistrarHotel registrarHotel = new RegistrarHotel();
		RegistrarCliente registrarCliente = new RegistrarCliente();
		RegistrarCategoriaArticulo registrarCategoria = new RegistrarCategoriaArticulo();
		RegistrarArticulo registrarArticulo = new RegistrarArticulo();
		RegistrarArticuloHotel registrarArticuloHotel = new RegistrarArticuloHotel();

		public ConectarDataBase()
		{
			cadenaConexion = ConfigurationManager.ConnectionStrings["conexionBD"].ConnectionString;
			//cadenaConexion = "DATA Source=localhost; Initial Catalog=RESORTSUNED; Trusted_Connection=True;";
		}

		public void ObtenerHoteles()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Select idHotel, Nombre, Direccion, Estado, Telefono FROM HOTEL";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while(reader.Read())
				{
					
					int idHotel = reader.GetInt32(0);
					string nombreHotel = reader.GetString(1);
					string descripcion = reader.GetString(2);
					bool estado = reader.GetBoolean(3);
					string telefono = reader.GetString(4);

					Hotel hotelObtenido = new Hotel(idHotel, nombreHotel, descripcion, estado, telefono);

					registrarHotel.AgregarHotel(InicializarListas.lista_hoteles, hotelObtenido);

				}
			}
			
			conexion.Close();
		}

		public void AgregarHotel (Hotel hotel)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into Hotel(IdHotel, Nombre, Direccion, Estado, Telefono) " +
				"Values(@IdHotel, @Nombre, @Direccion, @Estado, @Telefono)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			comando.Parameters.AddWithValue("@IdHotel", hotel.Id);
			comando.Parameters.AddWithValue("@Nombre", hotel.NombreHotel);
			comando.Parameters.AddWithValue("@Direccion", hotel.Direccion);
			comando.Parameters.AddWithValue("@Estado", hotel.Estado);
			comando.Parameters.AddWithValue("@Telefono", hotel.Telefono);

			conexion.Open();
			comando.ExecuteNonQuery();
			conexion.Close() ;
		}

		public void ObtenerClientes()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Select idCliente, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento, Genero FROM Cliente";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					string idCliente = reader.GetString(0);
					string nombre = reader.GetString(1);
					string primerapellido = reader.GetString(2);
					string segundopellido = reader.GetString(3);
					DateTime fechaNacimiento = reader.GetDateTime(4);
					char genero = reader.GetString(5)[0];

					Cliente clienteObtenido = new Cliente(idCliente, nombre, primerapellido, segundopellido, fechaNacimiento, genero);

					registrarCliente.AgregarCliente(InicializarListas.lista_clientes, clienteObtenido);

				}
			}

			conexion.Close();
		}

		public void AgregarCliente(Cliente cliente)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into Cliente(IdCliente, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento, Genero) " +
				"Values(@IdCliente, @Nombre, @PrimerApellido, @SegundoApellido, @FechaNacimiento, @Genero)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			comando.Parameters.AddWithValue("@IdCliente", cliente.Identificacion);
			comando.Parameters.AddWithValue("@Nombre", cliente.Nombre);
			comando.Parameters.AddWithValue("@PrimerApellido", cliente.Apellido1);
			comando.Parameters.AddWithValue("@SegundoApellido", cliente.Apellido2);
			comando.Parameters.AddWithValue("@FechaNacimiento", cliente.FechaNacimiento);
			comando.Parameters.AddWithValue("@Genero", cliente.Genero);

			conexion.Open();
			comando.ExecuteNonQuery();
			conexion.Close();
		}

		public void ObtenerCategoriaArticulos()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Select idCategoria, Descripcion, Estado FROM CategoriaArticulo";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					int idCategoria = reader.GetInt32(0);
					string descripcion = reader.GetString(1);
					bool estado = reader.GetBoolean(2);

					CategoriaArticulo categoriaArticuloObtenido = new CategoriaArticulo(idCategoria, descripcion, estado);

					registrarCategoria.AgregarCategoriaArticulo(InicializarListas.lista_categoriaArticulos, categoriaArticuloObtenido);

				}
			}

			conexion.Close();
		}

		public void AgregarCategoriaArticulo(CategoriaArticulo categoriaArticulo)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into CategoriaArticulo(idCategoria, Descripcion, Estado) " +
				"Values(@idCategoria, @Descripcion, @Estado)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			comando.Parameters.AddWithValue("@idCategoria", categoriaArticulo.IdCategoria);
			comando.Parameters.AddWithValue("@Descripcion", categoriaArticulo.Descripcion);
			comando.Parameters.AddWithValue("@Estado", categoriaArticulo.Estado);
			

			conexion.Open();
			comando.ExecuteNonQuery();
			conexion.Close();
		}

		public void ObtenerArticulos()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Select IdArticulo, Nombre, IdCategoria, Precio FROM Articulo";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					int idArticulo = reader.GetInt32(0);
					string nombre = reader.GetString(1);
					int idCategoria = reader.GetInt32(2);
					int precio = reader.GetInt32(3);
					CategoriaArticulo categoriaArticulo = InicializarListas.lista_categoriaArticulos.FirstOrDefault(obj => obj != null && obj.IdCategoria == idCategoria);

					Articulo articuloObtenido = new Articulo(idArticulo, nombre, precio, categoriaArticulo);

					registrarArticulo.AgregarArticulo(InicializarListas.lista_articulos, articuloObtenido);

				}
			}

			conexion.Close();
		}

		public void AgregarArticulo(Articulo articulo)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into Articulo(IdArticulo, Nombre, IdCategoria, Precio) " +
				"Values(@IdArticulo, @Nombre, @IdCategoria, @Precio)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			comando.Parameters.AddWithValue("@IdArticulo", articulo.IdArticulo);
			comando.Parameters.AddWithValue("@Nombre", articulo.Nombre);
			comando.Parameters.AddWithValue("@IdCategoria", articulo.IdCategoria.IdCategoria);
			comando.Parameters.AddWithValue("@Precio", articulo.Precio);


			conexion.Open();
			comando.ExecuteNonQuery();
			conexion.Close();
		}

		public void ObtenerArticulosHotel()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " SELECT IdAsignacion, IdHotel, FechaAsignacion, STRING_AGG(IdArticulo, ',') AS IdsArticulos " +
				"FROM ArticuloHotel " +
				"GROUP BY IdAsignacion, IdHotel, FechaAsignacion";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					int idAsignacion = reader.GetInt32(0);
					int idHotel = reader.GetInt32(1);
					DateTime fechaasignacion = reader.GetDateTime(2);
					string idArticulos = reader.GetString(3);

					List<Articulo> ArticulosList = new List<Articulo>();
					foreach (string idArticulo in idArticulos.Split(','))
					{
						ArticulosList.Add(InicializarListas.lista_articulos.FirstOrDefault(obj => obj != null &&
						obj.IdArticulo == int.Parse(idArticulo)));
					}
					Articulo[] arregloArticulos = ArticulosList.Take(10).ToArray();
					Hotel hotel = InicializarListas.lista_hoteles.FirstOrDefault(obj => obj != null && obj.Id == idHotel);

					ArticuloHotel articuloHotelObtenido = new ArticuloHotel(idAsignacion, fechaasignacion, hotel, arregloArticulos);
					registrarArticuloHotel.AgregarArticuloHotel(InicializarListas.lista_articulohotel, articuloHotelObtenido);

				}
			}

			conexion.Close();
		}

		public void AgregarArticuloHotel(ArticuloHotel articuloHotel)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into ArticuloHotel(IdAsignacion, IdHotel, IdArticulo, FechaAsignacion) " +
				"Values(@IdAsignacion, @IdHotel, @IdArticulo, @FechaAsignacion)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			var articulosnonulos = articuloHotel.Articulos.Where(obj => obj != null).ToArray();
			
			foreach (Articulo articulo in articulosnonulos)
			{
				comando.Parameters.Clear();
				comando.Parameters.AddWithValue("@IdAsignacion", articuloHotel.IdAsignacion);
				comando.Parameters.AddWithValue("@IdHotel", articuloHotel.Hotel.Id);
				comando.Parameters.AddWithValue("@IdArticulo", articulo.IdArticulo);
				comando.Parameters.AddWithValue("@FechaAsignacion", articuloHotel.Fecha);
				conexion.Open();
				comando.ExecuteNonQuery();
				conexion.Close();
			}
		}

		public List<int> ObtenerPedido()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);
			List<int> lista_id_Pedidos = new List<int>();

			sentencia = "SELECT IdPedido, IdCliente, FechaPedido, STRING_AGG(IdArticulo, ',') AS IdsArticulos "+ 
				" FROM Pedido " + 
				" GROUP BY IdPedido, IdCliente, FechaPedido ";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					int idPedido = reader.GetInt32(0);
					lista_id_Pedidos.Add(idPedido);
					string idCliente = reader.GetString(1);
					DateTime fechapedido = reader.GetDateTime(2);
					string idArticulos = reader.GetString(3);

					List<Articulo> ArticulosList = new List<Articulo>();
					foreach (string idArticulo in idArticulos.Split(','))
					{
						ArticulosList.Add(InicializarListas.lista_articulos.FirstOrDefault(obj => obj != null &&
						obj.IdArticulo == int.Parse(idArticulo)));
					}
					Articulo[] arregloArticulos = ArticulosList.Take(10).ToArray();
					Cliente cliente = InicializarListas.lista_clientes.FirstOrDefault(obj => obj != null && obj.Identificacion == idCliente);

					Pedido PedidoObtenido = new Pedido(idPedido, fechapedido, cliente, arregloArticulos);
				}	
			}
			conexion.Close();
			return lista_id_Pedidos;
		}

		public List<Pedido> ObtenerPedidoCliente()
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			SqlDataReader reader;
			conexion = new SqlConnection(cadenaConexion);
			List<Pedido> lista_Pedidos = new List<Pedido>();

			sentencia = "SELECT IdPedido, IdCliente, FechaPedido, STRING_AGG(IdArticulo, ',') AS IdsArticulos " +
				" FROM Pedido " +
				" GROUP BY IdPedido, IdCliente, FechaPedido ";

			conexion.Open();

			comando.CommandText = sentencia;
			comando.Connection = conexion;

			reader = comando.ExecuteReader();

			if (reader.HasRows)
			{
				while (reader.Read())
				{

					int idPedido = reader.GetInt32(0);
					string idCliente = reader.GetString(1);
					DateTime fechapedido = reader.GetDateTime(2);
					string idArticulos = reader.GetString(3);

					List<Articulo> ArticulosList = new List<Articulo>();
					foreach (string idArticulo in idArticulos.Split(','))
					{
						ArticulosList.Add(InicializarListas.lista_articulos.FirstOrDefault(obj => obj != null &&
						obj.IdArticulo == int.Parse(idArticulo)));
					}
					Articulo[] arregloArticulos = ArticulosList.Take(10).ToArray();
					Cliente cliente = InicializarListas.lista_clientes.FirstOrDefault(obj => obj != null && obj.Identificacion == idCliente);

					Pedido PedidoObtenido = new Pedido(idPedido, fechapedido, cliente, arregloArticulos);
					lista_Pedidos.Add(PedidoObtenido);
				}
			}
			conexion.Close();
			return lista_Pedidos;
		}

		public void AgregarPedido(Pedido pedido)
		{
			SqlConnection conexion;
			SqlCommand comando = new SqlCommand();
			string sentencia;
			conexion = new SqlConnection(cadenaConexion);

			sentencia = " Insert Into Pedido(IdPedido, IdCliente, IdArticulo, FechaPedido) " +
				"Values(@IdPedido, @IdCliente, @IdArticulo, @FechaPedido)";

			comando.CommandType = CommandType.Text;
			comando.CommandText = sentencia;
			comando.Connection = conexion;

			var articulosnonulos = pedido.Articulos.Where(obj => obj != null).ToArray();

			foreach (Articulo articulo in articulosnonulos)
			{
				comando.Parameters.Clear();
				comando.Parameters.AddWithValue("@IdPedido", pedido.IdPedido);
				comando.Parameters.AddWithValue("@IdCliente", pedido.Cliente.Identificacion);
				comando.Parameters.AddWithValue("@IdArticulo", articulo.IdArticulo);
				comando.Parameters.AddWithValue("@FechaPedido", pedido.FechaPedido);
				conexion.Open();
				comando.ExecuteNonQuery();
				conexion.Close();
			}
		}
	}
}

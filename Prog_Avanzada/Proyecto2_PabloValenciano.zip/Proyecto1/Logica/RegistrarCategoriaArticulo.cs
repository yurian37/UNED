﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class RegistrarCategoriaArticulo
	{
		public bool AgregarCategoriaArticulo(CategoriaArticulo[] lista_categoria_articulo, CategoriaArticulo categoriaArticulo_add)
		{
			if (!RevisarLleno(lista_categoria_articulo) && !RevisarIDRepetido(lista_categoria_articulo, categoriaArticulo_add.IdCategoria) && RevisarnoVacios(categoriaArticulo_add))
			{
				for (int i = 0; i < lista_categoria_articulo.Length; i++)
				{
					if (lista_categoria_articulo[i] == null)
					{
						lista_categoria_articulo[i] = categoriaArticulo_add;
						break;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}
		public bool RevisarLleno(CategoriaArticulo[] lista_categoria_articulo)
		{
			foreach (CategoriaArticulo elemento in lista_categoria_articulo)
			{
				if (elemento == null)
				{
					return false;
				}
			}
			return true;
		}

		private bool RevisarIDRepetido(CategoriaArticulo[] lista_categoria_articulo, int id)
		{
			foreach (CategoriaArticulo elemento in lista_categoria_articulo)
				if (elemento != null)
				{
					{
						if (id == elemento.IdCategoria)
						{
							return true;
						}
					}
				}
			return false;
		}

		private bool RevisarnoVacios(CategoriaArticulo categoriaArticulo)
		{
			if (categoriaArticulo.IdCategoria == -1 || categoriaArticulo.Descripcion == "")
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
}

﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class RegistrarHotel
	{
		public bool AgregarHotel(Hotel[] lista_hotel, Hotel hotel_add)
		{
			if (!RevisarLleno(lista_hotel) && !RevisarIDRepetido(lista_hotel, hotel_add.Id) && RevisarnoVacios(hotel_add))
			{
				for (int i = 0; i < lista_hotel.Length; i++)
				{
					if (lista_hotel[i] == null)
					{
						lista_hotel[i] = hotel_add;
						break;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}
		public bool RevisarLleno(Hotel[] lista_hotel)
		{
			foreach (Hotel elemento in lista_hotel)
			{
				if (elemento == null)
				{
					return false;
				}
			}
			return true;
		}

		private bool RevisarIDRepetido(Hotel[] lista_hotel, int id)
		{
			foreach (Hotel elemento in lista_hotel)
				if (elemento != null)
				{
					{
						if (id == elemento.Id)
						{
							return true;
						}
					}
				}
			return false;
		}

		private bool RevisarnoVacios(Hotel hotel)
		{
			if (hotel.Id == -1 || hotel.NombreHotel == "" || hotel.Direccion == "" || hotel.Telefono == "")
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
}

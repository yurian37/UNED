﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class RegistrarArticuloHotel
	{
		public bool AgregarArticuloHotel(ArticuloHotel[] lista_articuloHotel, ArticuloHotel articuloHotel_add)
		{
			if (!RevisarLleno(lista_articuloHotel) && !RevisarIDRepetido(lista_articuloHotel, articuloHotel_add.IdAsignacion) && RevisarnoVacios(articuloHotel_add))
			{
				for (int i = 0; i < lista_articuloHotel.Length; i++)
				{
					if (lista_articuloHotel[i] == null)
					{
						lista_articuloHotel[i] = articuloHotel_add;
						break;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool RevisarLleno(ArticuloHotel[] lista_articuloHotel)
		{
			foreach (ArticuloHotel elemento in lista_articuloHotel)
			{
				if (elemento == null)
				{
					return false;
				}
			}
			return true;
		}

		private bool RevisarIDRepetido(ArticuloHotel[] lista_articuloHotel, int id)
		{
			foreach (ArticuloHotel elemento in lista_articuloHotel)
				if (elemento != null)
				{
					{
						if (id == elemento.IdAsignacion)
						{
							return true;
						}
					}
				}
			return false;
		}

		private bool RevisarnoVacios(ArticuloHotel articuloHotel)
		{
			if (articuloHotel.IdAsignacion == -1)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
}

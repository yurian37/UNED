﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class InicializarListas
	{

		static public Hotel[] lista_hoteles;
		static public CategoriaArticulo[] lista_categoriaArticulos;
		static public Articulo[] lista_articulos;
		static public Cliente[] lista_clientes;
		static public ArticuloHotel[] lista_articulohotel;

		static public void InicializaListas()
		{
			lista_hoteles = new Hotel[20];
			lista_categoriaArticulos = new CategoriaArticulo[20];
			lista_articulos = new Articulo[20];
			lista_clientes = new Cliente[20];
			lista_articulohotel = new ArticuloHotel[20];
		}
	}
}

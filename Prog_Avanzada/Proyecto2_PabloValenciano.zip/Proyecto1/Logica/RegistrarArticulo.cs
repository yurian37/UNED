﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* UNED I Cuatrimestre 2024
 * * Proyyect02: Aplicacion Resorts UNED
 * * Estudiante: Pablo Valenciano 115720043
 * * Fecha 06/04/2024
 * 
 * */

namespace Logica
{
	public class RegistrarArticulo
	{
		public bool AgregarArticulo(Articulo[] lista_articulo, Articulo articulo_add)
		{
			if (!RevisarLleno(lista_articulo) && !RevisarIDRepetido(lista_articulo, articulo_add.IdArticulo) 
				&& RevisarnoVacios(articulo_add) && RevisarCategoriaValida(articulo_add))
			{
				for (int i = 0; i < lista_articulo.Length; i++)
				{
					if (lista_articulo[i] == null)
					{
						lista_articulo[i] = articulo_add;
						break;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}
		public bool RevisarLleno(Articulo[] lista_articulo)
		{
			foreach (Articulo elemento in lista_articulo)
			{
				if (elemento == null)
				{
					return false;
				}
			}
			return true;
		}

		private bool RevisarIDRepetido(Articulo[] lista_articulo, int id)
		{
			foreach (Articulo elemento in lista_articulo)
				if (elemento != null)
				{
					{
						if (id == elemento.IdArticulo)
						{
							return true;
						}
					}
				}
			return false;
		}

		private bool RevisarnoVacios(Articulo articulo)
		{
			if (articulo.IdCategoria != null)
			{
				if (articulo.IdArticulo == -1 || articulo.Nombre == "" || articulo.Precio == -1 || articulo.IdCategoria.IdCategoria == -1)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
			else
			{
				return false;
			}
		}

		private bool RevisarCategoriaValida(Articulo articulo)
		{
			List<int> idsCategoria= new List<int>();
			foreach (CategoriaArticulo categoriaArticulo in InicializarListas.lista_categoriaArticulos)
			{
				if (categoriaArticulo != null)
				{
					idsCategoria.Add(categoriaArticulo.IdCategoria);
				}
			}

			if (idsCategoria.Contains(articulo.IdCategoria.IdCategoria)){ return true; }
			else { return false; }
		}
	}
}
